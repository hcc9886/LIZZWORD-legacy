# 0227 批次合并与校验（临时文件，批次号唯一）
import json
import re
import sys

import _tmp_0227_p1 as p1
import _tmp_0227_p2 as p2
import _tmp_0227_p3 as p3

TARGET = [
    "due to", "owing to", "regardless of", "in the absence of", "on the contrary",
    "to some extent", "accessibility", "adequacy", "autonomy", "coherence",
    "coincidence", "convergence", "credibility", "culmination", "discrepancy",
]
KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene",
        "sceneCN", "pos", "collocations", "forms", "derivatives", "senses", "etymology",
        "similar", "mnemonics", "examples", "dict_mnemonic", "root", "sensesIntro",
        "semanticMap", "affixes"]
SKEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

data = p1.WORDS + p2.WORDS + p3.WORDS
errors = []


def err(msg):
    errors.append(msg)


def walk_strings(node, path):
    if isinstance(node, str):
        yield path, node
    elif isinstance(node, dict):
        for k, v in node.items():
            yield from walk_strings(v, path + "." + k)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from walk_strings(v, "%s[%d]" % (path, i))


# 生成文件
out_path = "/Users/hcc/Desktop/LIZZWORD/books/prepared/toefl-core-5000-0227.json"
if len(data) != 15:
    err("记录数不是 15：%d" % len(data))
if [r["word"] for r in data] != TARGET:
    err("词序与要求不一致：%s" % [r["word"] for r in data])

with open(out_path, "w", encoding="utf-8") as fp:
    json.dump(data, fp, ensure_ascii=False, indent=1)
    fp.write("\n")

size = len(open(out_path, "rb").read())
senses_total = sum(len(r["senses"]) for r in data)

# 结构校验
for r in data:
    w = r["word"]
    if list(r.keys()) != KEYS:
        err("%s 顶层键序不符：%s" % (w, list(r.keys())))
    if len(r["pos"]) < 1:
        err("%s pos 为空" % w)
    if len(r["collocations"]) < 4:
        err("%s 搭配不足 4 条" % w)
    if len(r["forms"]) < 3:
        err("%s forms 过少" % w)
    if len(r["derivatives"]) < 3:
        err("%s 派生词过少" % w)
    sn = len(r["senses"])
    if not (8 <= sn <= 10):
        err("%s 义项数 %d 不在 8-10" % (w, sn))
    for i, s in enumerate(r["senses"], 1):
        if list(s.keys()) != SKEYS:
            err("%s 义项 %d 键不符" % (w, i))
        if s["no"] != "%02d" % i:
            err("%s 义项编号断链：%s != %02d" % (w, s["no"], i))
    if r["senses"][0]["example"].count("") == 0:
        pass
    ei = len(r["etymology"]["items"])
    if not (5 <= ei <= 6):
        err("%s 词源段数 %d 不在 5-6" % (w, ei))
    for it in r["etymology"]["items"]:
        if not re.search(r"[A-Z]", it["era"]):
            err("%s 词源 era 未大写：%s" % (w, it["era"]))
    groups = r["similar"]["groups"]
    if len(groups) != 2:
        err("%s similar 组数不是 2" % w)
    for g in groups:
        if len(g["entries"]) != 5:
            err("%s similar 组 %s 条目数 %d" % (w, g["heading"], len(g["entries"])))
    if len(r["mnemonics"]["normal"]) != 5:
        err("%s 正常联想不足 5 条" % w)
    if len(r["mnemonics"]["abstract"]) != 3:
        err("%s 抽象联想不足 3 条" % w)
    if len(r["examples"]) != 3:
        err("%s 例句数不是 3" % w)
    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        err("%s 语义链不是 6 环" % w)
    if len(sm["branches"]) != 5:
        err("%s 分支数不是 5" % w)
    used = []
    valid = {s["no"] for s in r["senses"]}
    for b in sm["branches"]:
        refs = [x.strip() for x in b["senses"].split("·")]
        if not refs:
            err("%s 分支无编号" % w)
        for x in refs:
            if x not in valid:
                err("%s 分支编号悬空：%s" % (w, x))
            used.append(x)
    if len(used) != len(set(used)):
        err("%s 分支编号重复：%s" % (w, used))
    if len(r["affixes"]["items"]) < 8 or len(r["affixes"]["items"]) > 12:
        err("%s 词缀条目数 %d 不在 8-12" % (w, len(r["affixes"]["items"])))
    if len(r["affixes"]["derivatives"]) < 3:
        err("%s 词缀派生不足" % w)
    if not isinstance(r["affixes"]["latinEntries"], list):
        err("%s latinEntries 不是数组" % w)
    # 空值与零宽
    for path, s in walk_strings(r, w):
        if s.strip() == "":
            err("%s 空串：%s" % (w, path))
        if "undefined" in s or "null" in s:
            err("%s 出现 undefined/null：%s" % (w, path))
        if re.search("[\\u200b-\\u200d\\ufeff\\u2060]", s):
            err("%s 出现零宽字符：%s" % (w, path))
    # 英文例句含目标词
    for i, e in enumerate(r["examples"], 1):
        if not re.search(r"\b%s\b" % re.escape(w), e["en"], re.I):
            err("%s 例句 %d 缺目标词：%s" % (w, i, e["en"]))
    for i, s in enumerate(r["senses"], 1):
        if not re.search(r"\b%s\b" % re.escape(w), s["example"], re.I):
            err("%s 义项 %d 例句缺目标词：%s" % (w, i, s["example"]))


# 场景校验：中文铺垫无拉丁字母与数字；英文句含目标词恰好一次；挖空自测
def js_forms(word):
    forms = {word, word + "s", word + "es", word + "ed", word + "ing", word + "d"}
    if word.endswith("e"):
        forms.add(word[:-1] + "ing")
    last = word[-1]
    forms.add(word + last + "ing")
    forms.add(word + last + "ed")
    return sorted(forms, key=len, reverse=True)


for r in data:
    w = r["word"]
    scene = r["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        err("%s 场景无英文句" % w)
        continue
    prefix = scene[:m.start()]
    if re.search(r"[A-Za-z0-9]", prefix):
        err("%s 中文铺垫含拉丁字母或数字：%s" % (w, prefix))
    sentence = scene[m.start():]
    cnt = len(re.findall(r"\b%s\b" % re.escape(w), sentence, re.I))
    if cnt != 1:
        err("%s 场景句目标词出现 %d 次：%s" % (w, cnt, sentence))
    for f in js_forms(w):
        if re.search(r"\b%s\b" % re.escape(f), sentence, re.I):
            blanked = re.sub(r"\b%s\b" % re.escape(f), "____", sentence, count=1, flags=re.I)
            if "____" not in blanked:
                err("%s 挖空失败" % w)
            if len(re.findall(r"\b%s\b" % re.escape(f), sentence, re.I)) != 1:
                err("%s 挖空词形出现多次：%s" % (w, f))
            break

# 中文字段字母扫描（词源 cn 与 root 允许拉丁引文）
def cn_fields(r):
    yield "definition_zh", r["definition_zh"]
    yield "core_image", r["core_image"]
    yield "scene_prefix", r["scene"][:re.search(r"[A-Za-z]", r["scene"]).start()]
    yield "sceneCN", r["sceneCN"]
    for i, x in enumerate(r["pos"]):
        yield "pos.zh[%d]" % i, x["zh"]
    for i, x in enumerate(r["collocations"]):
        yield "collocations.zh[%d]" % i, x["zh"]
    for i, x in enumerate(r["forms"]):
        yield "forms.label[%d]" % i, x["label"]
    for i, x in enumerate(r["derivatives"]):
        yield "derivatives.zh[%d]" % i, x["zh"]
    for i, s in enumerate(r["senses"]):
        yield "senses[%d].titleCN" % i, s["titleCN"]
        yield "senses[%d].definitionCN" % i, s["definitionCN"]
        yield "senses[%d].exampleCN" % i, s["exampleCN"]
        yield "senses[%d].whyCN" % i, s["whyCN"]
    yield "similar.note.cn", r["similar"]["note"]["cn"]
    for gi, g in enumerate(r["similar"]["groups"]):
        for i, e in enumerate(g["entries"]):
            yield "similar[%d][%d].definitionCN" % (gi, i), e["definitionCN"]
    yield "mnemonics.normalIntro.cn", r["mnemonics"]["normalIntro"]["cn"]
    for i, x in enumerate(r["mnemonics"]["normal"]):
        yield "mnemonics.normal[%d].cn" % i, x["cn"]
    for i, x in enumerate(r["mnemonics"]["abstract"]):
        yield "mnemonics.abstract[%d].cn" % i, x["cn"]
    for i, x in enumerate(r["examples"]):
        yield "examples[%d].cn" % i, x["cn"]
    yield "dict_mnemonic.note", r["dict_mnemonic"]["note"]
    yield "dict_mnemonic.text", r["dict_mnemonic"]["text"]
    yield "sensesIntro.cn", r["sensesIntro"]["cn"]
    yield "semanticMap.core.cn", r["semanticMap"]["core"]["cn"]
    for i, b in enumerate(r["semanticMap"]["branches"]):
        yield "semanticMap.branches[%d].cn" % i, b["cn"]
    yield "affixes.intro.cn", r["affixes"]["intro"]["cn"]
    yield "affixes.latinIntro.cn", r["affixes"]["latinIntro"]["cn"]
    for i, x in enumerate(r["affixes"]["items"]):
        yield "affixes.items[%d].meaningCN" % i, x["meaningCN"]
        yield "affixes.items[%d].exampleCN" % i, x["exampleCN"]
    for i, x in enumerate(r["affixes"]["derivatives"]):
        yield "affixes.derivatives[%d].zh" % i, x["zh"]


for r in data:
    for name, s in cn_fields(r):
        if re.search(r"[A-Za-z]", s):
            err("%s 中文字段含拉丁字母 %s：%s" % (r["word"], name, s))

# 重名检查
import glob
import os
others = set()
for f in sorted(glob.glob("/Users/hcc/Desktop/LIZZWORD/books/prepared/toefl-core-5000-*.json")):
    if os.path.basename(f) == "toefl-core-5000-0227.json":
        continue
    try:
        d = json.load(open(f, encoding="utf-8"))
    except Exception:
        continue
    if not isinstance(d, list):
        continue
    for x in d:
        if isinstance(x, dict) and "word" in x:
            others.add(x["word"])
dups = [w for w in TARGET if w in others]
unique_all = len(others | set(TARGET))

print("文件：", out_path)
print("字节数：", size)
print("记录数：", len(data), "义项总数：", senses_total)
print("全库唯一词数：", unique_all, "重复词：", dups)
print("错误数：", len(errors))
for e in errors:
    print(" -", e)
sys.exit(1 if errors else 0)
