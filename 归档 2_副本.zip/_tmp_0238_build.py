# -*- coding: utf-8 -*-
"""批次 0238 构建入口：装配 15 条词条并按固定键序落盘。"""

import json

from _tmp_0238_common import EXPECTED, TOP_KEYS
from _tmp_0238_p1 import PART1
from _tmp_0238_p2 import PART2
from _tmp_0238_p3 import PART3

WORDS = PART1 + PART2 + PART3
assert len(WORDS) == 15, len(WORDS)
assert [w["word"] for w in WORDS] == EXPECTED, [w["word"] for w in WORDS]

OUT = "/Users/hcc/Desktop/LIZZWORD/books/prepared/toefl-core-5000-0238.json"
with open(OUT, "w", encoding="utf-8") as f:
    json.dump(WORDS, f, ensure_ascii=False, indent=1)

print("written", OUT)
print("entries", len(WORDS))
print("senses total", sum(len(w["senses"]) for w in WORDS))
for w in WORDS:
    assert list(w.keys()) == TOP_KEYS
