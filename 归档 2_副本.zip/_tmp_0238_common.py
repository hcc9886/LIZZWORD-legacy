# -*- coding: utf-8 -*-
"""批次 0238 构建公共件：统一键序与构造器，避免漏键/换序。"""

TOP_KEYS = [
    "word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image",
    "scene", "sceneCN", "pos", "collocations", "forms", "derivatives", "senses",
    "etymology", "similar", "mnemonics", "examples", "dict_mnemonic", "root",
    "sensesIntro", "semanticMap", "affixes",
]

SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]


def S(no, title, titleCN, definition, definitionCN, example, exampleCN, why, whyCN):
    return {
        "no": no, "title": title, "titleCN": titleCN,
        "definition": definition, "definitionCN": definitionCN,
        "example": example, "exampleCN": exampleCN,
        "why": why, "whyCN": whyCN,
    }


def ET(era, en, cn):
    return {"era": era, "en": en, "cn": cn}


def BR(senses, en, cn):
    return {"senses": senses, "en": en, "cn": cn}


def COL(phrase, zh):
    return {"phrase": phrase, "zh": zh}


def FORM(label, form):
    return {"label": label, "form": form}


def DER(word, pos, zh):
    return {"word": word, "pos": pos, "zh": zh}


def AFX(word, structure, meaning, meaningCN, example, exampleCN):
    return {"word": word, "structure": structure, "meaning": meaning,
            "meaningCN": meaningCN, "example": example, "exampleCN": exampleCN}


def LEX(word, structure, meaning, meaningCN):
    return {"word": word, "structure": structure, "meaning": meaning, "meaningCN": meaningCN}


def SIMW(word, ipa, tag, definition, definitionCN):
    return {"word": word, "ipa": ipa, "tag": tag, "definition": definition, "definitionCN": definitionCN}


def MN(en, cn):
    return {"en": en, "cn": cn}


def entry(**kw):
    """按固定 22 键序装配词条，缺键直接报错。"""
    missing = [k for k in TOP_KEYS if k not in kw]
    extra = [k for k in kw if k not in TOP_KEYS]
    if missing or extra:
        raise ValueError("键不匹配 missing=%s extra=%s" % (missing, extra))
    item = {}
    for k in TOP_KEYS:
        item[k] = kw[k]
    # 结构自检
    assert len(item["senses"]) in (8, 9, 10), item["word"]
    for s in item["senses"]:
        assert list(s.keys()) == SENSE_KEYS, (item["word"], s.get("no"))
    assert len(item["semanticMap"]["chain"]) == 6, item["word"]
    assert len(item["semanticMap"]["branches"]) == 5, item["word"]
    assert len(item["etymology"]["items"]) in (5, 6), item["word"]
    assert 8 <= len(item["affixes"]["items"]) <= 12, item["word"]
    assert 5 <= len(item["collocations"]) <= 7, item["word"]
    assert len(item["mnemonics"]["normal"]) >= 5 and len(item["mnemonics"]["abstract"]) >= 3, item["word"]
    assert len(item["examples"]) == 3, item["word"]
    assert [g["heading"] for g in item["similar"]["groups"]] == ["LOOK-ALIKE", "NEAR MEANING"], item["word"]
    return item


EXPECTED = [
    "be indicative of", "be relevant to", "be susceptible to", "be equivalent to",
    "be proportional to", "be accompanied by", "be replaced by", "be restricted to",
    "a wide range of", "a variety of", "an increasing number of",
    "a significant proportion of", "a substantial amount of",
    "a considerable degree of", "at the expense of",
]
