import json, glob, os, re, sys

sys.path.insert(0, "books/prepared")
import _tmp_0229_p1 as m1
import _tmp_0229_p1b as m2
import _tmp_0229_p1c as m3
import _tmp_0229_p2 as m4
import _tmp_0229_p2b as m5
import _tmp_0229_p3 as m6
import _tmp_0229_p4 as m7

records = []
for mod, attr in [(m1, "DATA"), (m2, "DATA2"), (m3, "DATA3"), (m4, "DATA4"), (m5, "DATA5"), (m6, "DATA6"), (m7, "DATA7")]:
    records.extend(getattr(mod, attr))

ORDER = "skeptical sequential spatial temporal tangible tentative transparent trivial underlying uniform unique widespread rigorous obsolete intricate".split()
assert [r["word"] for r in records] == ORDER, [r["word"] for r in records]

KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene", "sceneCN", "pos",
        "collocations", "forms", "derivatives", "senses", "etymology", "similar", "mnemonics", "examples",
        "dict_mnemonic", "root", "sensesIntro", "semanticMap", "affixes"]
SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

errors = []

def check_nonempty(path, value):
    if value is None or (isinstance(value, str) and not value.strip()) or (isinstance(value, list) and not value):
        errors.append("EMPTY %s" % path)

for r in records:
    w = r["word"]
    if list(r.keys()) != KEYS:
        errors.append("KEY ORDER %s: %s" % (w, list(r.keys())))
    for k in KEYS:
        if k not in r:
            errors.append("MISSING %s.%s" % (w, k))
    if not (8 <= len(r["senses"]) <= 10):
        errors.append("SENSE COUNT %s %d" % (w, len(r["senses"])))
    for i, s in enumerate(r["senses"], 1):
        if list(s.keys()) != SENSE_KEYS:
            errors.append("SENSE KEY %s %d %s" % (w, i, list(s.keys())))
        if s["no"] != "%02d" % i:
            errors.append("SENSE NO %s %d %s" % (w, i, s["no"]))
        for k, v in s.items():
            check_nonempty("%s.senses[%d].%s" % (w, i, k), v)
    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        errors.append("CHAIN %s %d" % (w, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        errors.append("BRANCHES %s %d" % (w, len(sm["branches"])))
    for b in sm["branches"]:
        nums = [int(x) for x in re.findall(r"\d+", b["senses"])]
        if not nums:
            errors.append("BRANCH NO REF %s %s" % (w, b["senses"]))
        for n in nums:
            if n < 1 or n > len(r["senses"]):
                errors.append("BRANCH BAD REF %s %s (n=%d)" % (w, b["senses"], n))
    if not (5 <= len(r["etymology"]["items"]) <= 6):
        errors.append("ETYMOLOGY %s %d" % (w, len(r["etymology"]["items"])))
    if len(r["similar"]["groups"]) != 2:
        errors.append("SIMILAR GROUPS %s" % w)
    for g in r["similar"]["groups"]:
        if not g["entries"]:
            errors.append("SIMILAR EMPTY %s %s" % (w, g["heading"]))
    if len(r["mnemonics"]["normal"]) != 5 or len(r["mnemonics"]["abstract"]) != 3:
        errors.append("MNEMONICS %s %d/%d" % (w, len(r["mnemonics"]["normal"]), len(r["mnemonics"]["abstract"])))
    if len(r["examples"]) != 3:
        errors.append("EXAMPLES %s %d" % (w, len(r["examples"])))
    if len(r["collocations"]) < 4:
        errors.append("COLLOCATIONS %s" % w)
    if not (8 <= len(r["affixes"]["items"]) <= 12):
        errors.append("AFFIX ITEMS %s %d" % (w, len(r["affixes"]["items"])))
    if not r["affixes"]["derivatives"]:
        errors.append("AFFIX DERIV %s" % w)
    # 空值 / 占位串
    raw = json.dumps(r, ensure_ascii=False)
    for bad in ["undefined", "null", "\u200b", "\u200c", "\u200d", "\ufeff"]:
        if bad in raw:
            errors.append("BAD TOKEN %s %s" % (w, bad))
    # scene 结构自测
    scene = r["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        errors.append("SCENE NO EN %s" % w)
        continue
    preamble, sentence = scene[:m.start()], scene[m.start():]
    if re.search(r"[A-Za-z0-9]", preamble):
        errors.append("SCENE PREAMBLE LATIN/DIGIT %s: %s" % (w, preamble))
    forms = {w, w + "s", w + "es", w + "ed", w + "ing", w + "d"}
    if w.endswith("e"):
        forms.add(w[:-1] + "ing")
    forms.add(w + w[-1] + "ing")
    forms.add(w + w[-1] + "ed")
    hits = []
    for f in sorted(forms, key=len, reverse=True):
        hits.extend(re.findall(r"\b%s\b" % re.escape(f), sentence, flags=re.I))
    if len(hits) != 1:
        errors.append("SCENE WORD ONCE %s hits=%s" % (w, hits))
    # 中文栏目混入拉丁字母（排除 scene 与英文典型字段）
    cn_fields = [(k, r[k]) for k in ["definition_zh", "core_image", "sceneCN", "root"]]
    cn_fields.append(("dict_text", r["dict_mnemonic"]["text"]))
    cn_fields.append(("sensesIntro.cn", r["sensesIntro"]["cn"]))
    cn_fields.append(("semanticMap.core.cn", r["semanticMap"]["core"]["cn"]))
    for i, s in enumerate(r["senses"], 1):
        cn_fields.append(("senses[%d].titleCN" % i, s["titleCN"]))
        cn_fields.append(("senses[%d].definitionCN" % i, s["definitionCN"]))
        cn_fields.append(("senses[%d].exampleCN" % i, s["exampleCN"]))
        cn_fields.append(("senses[%d].whyCN" % i, s["whyCN"]))
    for i, e in enumerate(r["examples"], 1):
        cn_fields.append(("examples[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["normal"], 1):
        cn_fields.append(("mnormal[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["abstract"], 1):
        cn_fields.append(("mabstract[%d].cn" % i, e["cn"]))
    for f, v in cn_fields:
        if re.search(r"[A-Za-z]", v):
            errors.append("CN LATIN %s.%s: %s" % (w, f, v))

# 全库重名
existing = {}
files = [f for f in glob.glob("books/prepared/toefl-core-5000-*.json") if "0229" not in f]
for f in files:
    try:
        d = json.load(open(f))
    except Exception:
        continue
    if isinstance(d, list):
        for rec in d:
            if isinstance(rec, dict) and "word" in rec:
                existing.setdefault(rec["word"].lower(), []).append(os.path.basename(f))
for r in records:
    if r["word"].lower() in existing:
        errors.append("DUPLICATE %s in %s" % (r["word"], existing[r["word"].lower()]))

if errors:
    print("ERRORS:", len(errors))
    for e in errors:
        print(" -", e)
    sys.exit(1)

out = "books/prepared/toefl-core-5000-0229.json"
with open(out, "w", encoding="utf-8") as fh:
    json.dump(records, fh, ensure_ascii=False, indent=2)
print("WROTE", out, os.path.getsize(out), "bytes")
print("words", len(records), "senses", sum(len(r["senses"]) for r in records))
print("existing unique", len(existing), "our words", len(records))
