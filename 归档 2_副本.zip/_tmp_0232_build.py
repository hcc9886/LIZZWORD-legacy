# 0232 批次装配与全量校验（临时文件）
import json, re, glob, sys, os
from _tmp_0232_common import dump, rec
import _tmp_0232_p1 as p1
import _tmp_0232_p2 as p2
import _tmp_0232_p3 as p3

TARGET = "toefl-core-5000-0232.json"
KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene", "sceneCN",
        "pos", "collocations", "forms", "derivatives", "senses", "etymology", "similar", "mnemonics",
        "examples", "dict_mnemonic", "root", "sensesIntro", "semanticMap", "affixes"]
SKEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

records = p1.DATA + p2.DATA + p3.DATA
assert len(records) == 15, len(records)

errors = []
warnings = []

# 1 结构
for r in records:
    if list(r.keys()) != KEYS:
        errors.append("键序不符 %s: %s" % (r.get("word"), list(r.keys())))
    for sv in r["senses"]:
        if list(sv.keys()) != SKEYS:
            errors.append("senses 键不符 %s %s" % (r["word"], list(sv.keys())))
    n = len(r["senses"])
    if not 8 <= n <= 10:
        errors.append("义项数越界 %s %d" % (r["word"], n))
    nos = [sv["no"] for sv in r["senses"]]
    if [("%02d" % (i + 1)) for i in range(n)] != nos:
        errors.append("义项编号不连续 %s %s" % (r["word"], nos))
    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        errors.append("主链非6环 %s %d" % (r["word"], len(sm["chain"])))
    if len(sm["branches"]) != 5:
        errors.append("分支数非5 %s %d" % (r["word"], len(sm["branches"])))
    for b in sm["branches"]:
        nums = [x.strip() for x in re.split("·", b["senses"])]
        for x in nums:
            if x not in nos:
                errors.append("分支回指无效 %s %s" % (r["word"], b["senses"]))
    et = r["etymology"]["items"]
    if not 5 <= len(et) <= 6:
        errors.append("词源段数越界 %s %d" % (r["word"], len(et)))
    for it in et:
        if not it["era"] or not it["era"].isupper():
            errors.append("era 未大写 %s %s" % (r["word"], it["era"]))
    if not 4 <= len(r["collocations"]) <= 7:
        errors.append("搭配数越界 %s %d" % (r["word"], len(r["collocations"])))
    if not 8 <= len(r["affixes"]["items"]) <= 12:
        errors.append("词缀条数越界 %s %d" % (r["word"], len(r["affixes"]["items"])))
    if len(r["similar"]["groups"]) != 2:
        errors.append("similar 组数 %s" % r["word"])
    if len(r["similar"]["groups"][0]["entries"]) < 4 or len(r["similar"]["groups"][1]["entries"]) < 4:
        errors.append("similar 条数不足 %s" % r["word"])
    if len(r["mnemonics"]["normal"]) != 5 or len(r["mnemonics"]["abstract"]) != 3:
        errors.append("联想条数 %s" % r["word"])
    if len(r["examples"]) != 3:
        errors.append("例句数 %s" % r["word"])

# 2 空值扫描
def walk(o, path, w):
    if isinstance(o, dict):
        for k, v in o.items():
            walk(v, path + "." + k, w)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            walk(v, path + "[%d]" % i, w)
    elif isinstance(o, str):
        t = o.strip()
        if t == "" or t in ("undefined", "null", "None", "NA", "N/A", "占位"):
            errors.append("空值/占位 %s %s" % (w, path))
    elif o is None:
        errors.append("null 值 %s %s" % (w, path))

for r in records:
    walk(r, "", r["word"])

# 3 场景挖空自测（复刻页面逻辑）
def forms_of(word):
    out = [word, word + "s", word + "es", word + "ed", word + "ing", word + "d"]
    return out

def scene_sentence(scene):
    m = re.search("[A-Za-z]", scene)
    return scene[m.start():] if m else ""

def test_blank(r):
    w = r["word"]
    sc = r["scene"]
    head = sc[:re.search("[A-Za-z]", sc).start()] if re.search("[A-Za-z]", sc) else ""
    if re.search("[A-Za-z0-9]", head):
        errors.append("场景中文铺垫含拉丁字母或数字 %s" % w)
    sent = scene_sentence(sc)
    if re.search("[^\\x00-\\x7F]", sent):
        errors.append("场景英文句含非 ASCII 字符 %s" % w)
    hit = 0
    for word_ in [w, w + "s", w + "d"] + [w]:
        pat = re.compile(r"\b" + re.escape(word_) + r"\b", re.I)
        hit = max(hit, len(pat.findall(sent)))
    if hit != 1:
        errors.append("场景目标词出现次数=%d %s" % (hit, w))
    # 整段短语无障碍
    if not re.search(r"\b" + re.escape(w) + r"\b", sent, re.I) and not re.search(
            r"\b" + re.escape(w + "s") + r"\b", sent, re.I) and not re.search(
            r"\b" + re.escape(w + "d") + r"\b", sent, re.I):
        errors.append("场景未含目标词 %s" % w)
    # sceneCN 引义项
    if not re.search("第 ?[0-9一二三四五六七八九十]+ ?个义项", r["sceneCN"]):
        errors.append("sceneCN 未引义项 %s" % w)

for r in records:
    test_blank(r)

# 4 例句含目标词
for r in records:
    w = r["word"]
    pat = re.compile(r"\b" + re.escape(w) + r"(s|d|es|ed|ing)?\b", re.I)
    for i, e in enumerate(r["examples"]):
        if not pat.search(e["en"]):
            errors.append("例句%d缺目标词 %s" % (i + 1, w))
    for sv in r["senses"]:
        if not pat.search(sv["example"]):
            warnings.append("义项%s例句缺目标词 %s" % (sv["no"], w))

# 5 中文字段混入英文扫描
CN_FIELDS = ["definition_zh", "core_image", "sceneCN"]
for r in records:
    for fld in CN_FIELDS:
        if re.search("[A-Za-z]", r[fld]):
            errors.append("中文字段含英文 %s.%s" % (r["word"], fld))
    for c in r["collocations"]:
        if re.search("[A-Za-z]", c["zh"]):
            errors.append("中文搭配含英文 %s %s" % (r["word"], c["phrase"]))
    for dv in r["derivatives"]:
        if re.search("[A-Za-z]", dv["zh"]):
            errors.append("派生词中文含英文 %s %s" % (r["word"], dv["word"]))
    for sv in r["senses"]:
        for fld in ["titleCN", "definitionCN", "exampleCN", "whyCN"]:
            if re.search("[A-Za-z]", sv[fld]):
                errors.append("义项中文含英文 %s %s.%s" % (r["word"], sv["no"], fld))
    for g in r["similar"]["groups"]:
        for e in g["entries"]:
            pass  # similar 的对照词允许出现原词形
    for m in r["mnemonics"]["normal"] + r["mnemonics"]["abstract"]:
        if re.search("[A-Za-z]", m["cn"]):
            errors.append("联想中文含英文 %s" % r["word"])
    for e in r["examples"]:
        if re.search("[A-Za-z]", e["cn"]):
            errors.append("例句中文含英文 %s" % r["word"])
    if re.search("[A-Za-z]", r["dict_mnemonic"]["text"]):
        errors.append("谐音记忆含英文 %s" % r["word"])
    for fld in ["sensesIntro", "semanticMap", "affixes", "etymology", "mnemonics", "similar"]:
        pass
    if re.search("[A-Za-z]", r["sensesIntro"]["cn"]):
        errors.append("sensesIntro 中文含英文 %s" % r["word"])
    if re.search("[A-Za-z]", r["semanticMap"]["core"]["cn"]):
        errors.append("语义图核心中文含英文 %s" % r["word"])
    for ch in r["semanticMap"]["chain"]:
        pass  # 语义链按既有批次惯例使用英文短语
    for b in r["semanticMap"]["branches"]:
        if re.search("[A-Za-z]", b["cn"]):
            errors.append("分支中文含英文 %s" % r["word"])
    if re.search("[A-Za-z]", r["affixes"]["intro"]["cn"]) or re.search("[A-Za-z]", r["affixes"]["latinIntro"]["cn"]):
        errors.append("词缀导语中文含英文 %s" % r["word"])
    for a in r["affixes"]["items"]:
        if re.search("[A-Za-z]", a["meaningCN"]) or re.search("[A-Za-z]", a["exampleCN"]):
            errors.append("词缀中文含英文 %s %s" % (r["word"], a["word"]))
    if re.search("[A-Za-z]", r["mnemonics"]["normalIntro"]["cn"]):
        errors.append("联想导语中文含英文 %s" % r["word"])
    if re.search("[A-Za-z]", r["etymology"]["intro"]["cn"]):
        warnings.append("词源导语中文含拉丁文（允许引文，需人工判断） %s" % r["word"])
    # root 与词源中文允许拉丁/希腊语引文，单独报告
    if re.search("[A-Za-z]", r["root"]):
        warnings.append("root 含拉丁文（允许引文，需人工判断） %s" % r["word"])

# 6 重名检查
allw = {}
for f in sorted(glob.glob("toefl-core-5000-*.json")):
    if f.endswith(TARGET) or "diagnostic" in f:
        continue
    try:
        d = json.load(open(f))
    except Exception:
        continue
    if isinstance(d, list):
        for it in d:
            if isinstance(it, dict) and "word" in it:
                allw[it["word"]] = allw.get(it["word"], 0) + 1
batch = [r["word"] for r in records]
dups = [(w, allw.get(w)) for w in batch if allw.get(w)]
if dups:
    errors.append("与已交付批次重名 %s" % dups)

print("ERRORS:", len(errors))
for e in errors:
    print("  E:", e)
print("WARNINGS:", len(warnings))
for w in warnings:
    print("  W:", w)

if errors:
    sys.exit(1)

dump(records, TARGET)
size = os.path.getsize(TARGET)
print("WROTE", TARGET, size, "bytes")

# 7 落盘二次解析
back = json.load(open(TARGET, encoding="utf-8"))
assert isinstance(back, list) and len(back) == 15
for a, b in zip(records, back):
    assert list(b.keys()) == KEYS
    assert a["word"] == b["word"]
    assert len(b["senses"]) == len(a["senses"])
print("SECOND PARSE OK")
print("SENSES TOTAL", sum(len(r["senses"]) for r in records))
print("WORDS", len(records))
