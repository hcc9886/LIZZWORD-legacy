FILES = {
    "_tmp_0229_p2b.py": [
        ("透明的；公开透明的；易懂的；显而易见）", "透明的；公开透明的；易懂的；显而易见的"),
    ],
    "_tmp_0229_p1b.py": [
        ("（第 1 个义项：依次进行的）", "（第 1 个义项：按固定次序排列的）"),
    ],
    "_tmp_0229_p1c.py": [
        ("（第 1 个义项：空间的）", "（第 1 个义项：与空间有关的）"),
        ("（第 2 个义项：时间次序）", "（第 2 个义项：时间先后次序）"),
    ],
    "_tmp_0229_p3.py": [
        ("（第 1 个义项：根本的）", "（第 1 个义项：表象之下的根本原因）"),
        ("（第 1 个义项：统一的）", "（第 1 个义项：处处一致的）"),
    ],
    "_tmp_0229_p4.py": [
        ("（第 1 个义项：严格的）", "（第 1 个义项：严格而彻底的）"),
        ("（第 1 个义项：错综复杂的）", "（第 1 个义项：部件彼此咬合的）"),
        ("该前缀的具体作用各家解释不一，属词源细节存疑，非整词存疑。", "该前缀的具体作用各家解释不一。"),
    ],
}

for fn, pairs in FILES.items():
    path = "books/prepared/" + fn
    text = open(path, encoding="utf-8").read()
    for old, new in pairs:
        assert old in text, (fn, old)
        text = text.replace(old, new)
    open(path, "w", encoding="utf-8").write(text)
    print("fixed", fn)
