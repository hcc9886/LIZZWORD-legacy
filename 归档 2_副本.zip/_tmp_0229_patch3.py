import re

ROOTS = {
    "skeptical": "源于希腊语中表示「细看、考察」的动词，先指爱考察的人，再指把判断悬置起来的古代学派；词经拉丁语与法语进入英语。现代英语用不同字母拼写，是后来的习惯分化，分界年代不确定。",
    "sequential": "源于拉丁语中表示「跟随」的动词，其名词义为「跟随、连续」，形容词即在此词干上构成。同一词根还给出表示「顺序」「随后」「后果」的词；其中表示「随后」的那个加了「在后」的前缀，只指某一个较晚的项目，而这个词指队列内部的先后。",
    "spatial": "源于拉丁语中表示「空间、空地、距离」的名词，后起形容词义为「属于空间的」，再经法语进入英语。同族有表示「空间」与「宽敞」的词。十七世纪进入英语；各领域复合用法为后来扩展。",
    "temporal": "一支源于拉丁语中表示「时间」的名词及其形容词，教会又引申指「世俗的」；另一支源于拉丁语中表示「头部太阳穴」的复数名词，给出解剖学的「颞的」。两支同形异源，英语只在拼写上合并。",
    "tangible": "源于拉丁语中表示「触摸」的动词，其形容词义为「可触摸的」，经法语进入英语。同族有表示「切线」「触觉」「接触」与「无形」的词。十六世纪进入英语，十九世纪在会计中固定「有形资产」义；各引申义首见年代不确定。",
    "tentative": "源于拉丁语中表示「伸展、指向」的动词，其反复形式义为「试、试探」，再加形容词尾，经法语进入英语。表示「尝试」「引诱」的英语词与之同源，但不是由它直接派生。十六世纪进入英语；「初步协议」这一搭配首见年份不确定。",
    "transparent": "由拉丁语表示「穿过」的前缀与表示「显现」的动词合成，义为「透过显现」，其分词经法语进入英语。同族有表示「明显的」「外观」的词；形近而表示「泄露、蒸腾」的词出自表示「呼吸」的另一词根。十五世纪进入英语，计算机义为现代新增，首见年代不确定。",
    "trivial": "源于拉丁语中表示「三岔路口」的名词，由「三」与「道路」构成，派生形容词义为「属于三岔路的、平常的」。中世纪把三门基础学科合称三艺，于是又指「基础学科的」，再演变为「平常的」，最后成为「微不足道的」。数学「平凡解」义为十九世纪后的技术引申；各短语首见年代不确定。",
    "underlying": "英语本族复合词，由表示「在下」与表示「躺、位于」的两个古英语成分加上分词词尾构成。本义为「躺在下面」，引申为「根本的、潜在的、底层的」。金融的「标的资产」、医学的「基础疾病」、地质的「下伏岩层」都在这幅画面上各取一层；各技术用法首见年代不确定。",
    "uniform": "由拉丁语表示「一」的数词与表示「形状」的名词合成，义为「只有一种形状的」，经法语进入英语。同族有表示「一致性」「一致地」「穿制服的」的词；形近而表示「使成一体」的词出自表示「做」的另一动词，表示「独角兽」的词后半意为「角」。十六世纪进入英语；各技术短语首见年代不确定。",
    "unique": "源于拉丁语表示「一」的数词，其形容词义为「独一的」，经法语进入英语。同族有表示「单位」「独特性」「唯一地」的词；形近的「独角兽」后半意为「角」，「齐声」后半意为「声音」。十六世纪进入英语；口语弱化义的确切年代不确定。",
    "widespread": "英语本族复合词，由古英语表示「宽」的形容词与表示「散布」的动词构成，没有拉丁词根。十六世纪见于书面记录，确切的首次年份不确定。其反义方向为「独一无二」与「限于一地」。",
    "rigorous": "源于拉丁语表示「僵直」的动词，其名词义为「僵硬、严酷」，后起形容词再经法语进入英语。同族有表示「严格」「僵硬的」「刚性」的词；形近而表示「精力充沛」的词出自表示「有生气」的另一词根。十六世纪进入英语；各技术短语首见年代不确定。",
    "obsolete": "源于拉丁语表示「习惯于」的动词，其复合动词义为「渐不用、用坏」，过去分词义为「变旧废弃的」，经法语进入英语。该前缀的具体作用各家解释不一，属词源细节存疑，非整词存疑。十六世纪进入英语；「有计划地淘汰」一语首见年份不确定。",
    "intricate": "源于拉丁语表示「琐事、纠葛」的名词，其动词义为「缠住、使卷入」，过去分词进入英语作形容词。同族有表示「错综」的名词与表示「解脱」的动词；形近而表示「内在的」的词出自表示「向内」的另一词根。英语中表示「诡计」的词是否同出这一拉丁词，各家有争论而无定论。十五世纪进入英语；各技术用法首见年代不确定。",
}

BRANCHES = {
    "rigorous": '''    map_branches=[
        ("01", "THE STIFF PROCEDURE: care that refuses convenience in every ordinary step.", "僵硬的程序：在每个寻常步骤上都不为方便让步。"),
        ("02 · 04", "THE HARD TEST AND THE HARD DRILL: strict conditions, and training built under them.", "严苛的测试与艰苦的训练：严格的条件，以及在条件下筑起的训练。"),
        ("03 · 06", "THE CLOSED ARGUMENT: proofs and analyses with no step left to goodwill.", "封闭的论证：不把任何一步留给善意的证明与分析。"),
        ("05 · 08", "THE UNBENDING RULE: standards and enforcement that admit no exceptions.", "不肯弯的规则：不容例外开的标准与执行。"),
        ("07", "THE NARROW GATE: selection that only lets the tested through.", "窄门：只让过关者进入的筛选。"),
    ],''',
    "obsolete": '''    map_branches=[
        ("01 · 04", "THE RETIRED THING: an object or machine that newer things replaced.", "退役之物：被更新之物取代的器物或机器。"),
        ("02 · 05", "THE RETIRED WORD AND IDEA: what people no longer say or believe.", "退役的词与观念：人们不再说、也不再信的东西。"),
        ("03", "THE CLAUSE LEFT ON PAPER: a rule that practice has already abandoned.", "留在纸上的条款：实践早已放弃的规则。"),
        ("06 · 08", "THE SHELF AND THE HABIT: stock nobody buys, practices nobody follows.", "货架与习惯：无人购买的存货、无人沿用的做法。"),
        ("07", "THE WITHDRAWN UNIT: money or measures taken out of use by decree.", "撤销的单位：由法令停用的货币或计量单位。"),
    ],''',
    "intricate": '''    map_branches=[
        ("01 · 05", "THE INTERLOCKED MACHINE: parts that hold one another, from clocks to looms.", "咬合的机器：彼此扣住的部件，从钟表到织机。"),
        ("02 · 08", "THE FINE HAND: woven patterns and carving that reward close looking.", "精细的手：值得细看的织纹与雕刻。"),
        ("03", "THE DETAILS IN ORDER: small features that must be followed one by one.", "按序的细节：必须逐一追究的细小特征。"),
        ("04", "THE RETURNING PLOT: threads that cross and come back to the same scene.", "回返的情节：交叉之后又回到同一场景的线索。"),
        ("06 · 07", "THE KNOTTED WORLD: problems and relationships whose causes overlap.", "打结的世界：原因彼此重叠的问题与关系。"),
    ],''',
}

FILES = ["_tmp_0229_p1.py", "_tmp_0229_p1b.py", "_tmp_0229_p1c.py", "_tmp_0229_p2.py",
         "_tmp_0229_p2b.py", "_tmp_0229_p3.py", "_tmp_0229_p4.py"]
for fn in FILES:
    path = "books/prepared/" + fn
    text = open(path, encoding="utf-8").read()
    # 替换 root：按最近的 word= 判断属于哪条记录
    lines = text.split("\n")
    current = None
    for i, line in enumerate(lines):
        m = re.match(r'\s+word="([a-z]+)"', line)
        if m:
            current = m.group(1)
        if re.match(r'\s+root="', line) and current in ROOTS:
            indent = line[: len(line) - len(line.lstrip())]
            lines[i] = indent + 'root="' + ROOTS[current] + '",'
    text = "\n".join(lines)
    # 替换 semanticMap 分支块
    for word, block in BRANCHES.items():
        marker = '    word="%s"' % word
        if marker not in text:
            continue
        start = text.index(marker)
        bstart = text.index("    map_branches=[", start)
        bend = text.index("\n    ],\n", bstart) + len("\n    ],")
        text = text[:bstart] + block + text[bend:]
    # 局部文本修正
    text = text.replace('这个句子以由「after」引导的时间从句开头。',
                        '这个句子以表示「之后」的连接词引导的时间从句开头。')
    text = text.replace('absolute 形近，却属于「解开」，不属于「变旧」。',
                        '形近的那个词属于「解开」，不属于「变旧」。')
    text = text.replace('三门基础学科合称 trivium，所以这个词曾经意为「基础的」，而不是「无价值的」。',
                        '三门基础学科合称三艺，所以这个词曾经意为「基础的」，而不是「无价值的」。')
    open(path, "w", encoding="utf-8").write(text)
    print("updated", fn)
