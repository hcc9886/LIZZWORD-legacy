import json, glob, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "toefl-core-5000-0236.json")
ORDER = ["be consistent with", "be derived from", "be exposed to", "be responsible for", "bring about",
         "carry out", "come into existence", "consist of", "contribute to", "cope with",
         "depend on", "distinguish between", "give rise to", "have an impact on", "have access to"]
KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene", "sceneCN", "pos",
        "collocations", "forms", "derivatives", "senses", "etymology", "similar", "mnemonics", "examples",
        "dict_mnemonic", "root", "sensesIntro", "semanticMap", "affixes"]
SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

errors = []
with open(OUT, encoding="utf-8") as fh:
    raw = fh.read()
data = json.loads(raw)

if not isinstance(data, list):
    errors.append("TOP NOT ARRAY: %s" % type(data))
if len(data) != 15:
    errors.append("TOP LEN %d" % len(data))
if [r.get("word") for r in data] != ORDER:
    errors.append("ORDER MISMATCH: %s" % [r.get("word") for r in data])


def empty_scan(obj, path, out):
    if obj is None:
        out.append("NULL " + path)
    elif isinstance(obj, str):
        if not obj.strip():
            out.append("BLANKSTR " + path)
    elif isinstance(obj, (list, tuple)):
        if not obj:
            out.append("EMPTYLIST " + path)
        for i, v in enumerate(obj):
            empty_scan(v, "%s[%d]" % (path, i), out)
    elif isinstance(obj, dict):
        if not obj:
            out.append("EMPTYDICT " + path)
        for k, v in obj.items():
            empty_scan(v, "%s.%s" % (path, k), out)


CN_FIELDS = ("definition_zh", "core_image", "sceneCN", "root")
TRAD = set("個們來時說會發現這樣為與學問長間開對從無觀點後裡麼應該還讓給過於將種號稱據處實際體變導遊歷產業務區塊圖網絡資訊數")
LATIN = re.compile(r"[A-Za-z]")
CYR = re.compile(r"[\u0400-\u04FF]")

seen_words = []
for r in data:
    w = r["word"]
    seen_words.append(w)
    if list(r.keys()) != KEYS:
        errors.append("KEYS %s %s" % (w, list(r.keys())))
    if len(r["senses"]) < 8 or len(r["senses"]) > 10:
        errors.append("SENSES COUNT %s %d" % (w, len(r["senses"])))
    for i, s in enumerate(r["senses"], 1):
        if list(s.keys()) != SENSE_KEYS:
            errors.append("SENSE KEYS %s %d" % (w, i))
        if s["no"] != "%02d" % i:
            errors.append("SENSE NO %s %d %s" % (w, i, s["no"]))
        if not re.search(r"\b%s\b" % re.escape(w), s["example"], flags=re.I):
            errors.append("SENSE EXAMPLE NO PHRASE %s %d" % (w, i))

    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        errors.append("CHAIN %s %d" % (w, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        errors.append("BRANCH %s %d" % (w, len(sm["branches"])))
    refs = []
    for b in sm["branches"]:
        nums = [int(x) for x in re.findall(r"\d+", b["senses"])]
        if not nums:
            errors.append("BRANCH NO REF %s" % w)
        refs.extend(nums)
        for n in nums:
            if not (1 <= n <= len(r["senses"])):
                errors.append("BRANCH BAD %s %s" % (w, b["senses"]))
    if len(refs) != len(set(refs)):
        errors.append("BRANCH DUP REF %s %s" % (w, refs))
    missing = [n for n in range(1, len(r["senses"]) + 1) if n not in refs]
    if missing:
        errors.append("BRANCH MISSING SENSES %s %s" % (w, missing))

    if not (5 <= len(r["etymology"]["items"]) <= 6):
        errors.append("ETY %s %d" % (w, len(r["etymology"]["items"])))

    empties = []
    empty_scan(r, w, empties)
    errors.extend([e for e in empties if ".affixes.latinEntries" not in e])
    for key in ("latinEntries",):
        if not r["affixes"].get(key) and w not in ("bring about", "give rise to"):
            errors.append("LATIN ENTRIES EMPTY %s" % w)

    # scene 自测
    scene = r["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        errors.append("SCENE NO EN %s" % w)
        continue
    pre, sent = scene[:m.start()], scene[m.start():]
    if re.search(r"[A-Za-z0-9]", pre):
        errors.append("PREAMBLE LATIN/DIGIT %s" % w)
    if re.search(r"\b(denied|refuted|implied|arises)\b", sent, flags=re.I):
        errors.append("SCENE BAD FORM %s" % w)
    occ = len(re.findall(r"\b%s\b" % re.escape(w), sent, flags=re.I))
    if occ != 1:
        errors.append("SCENE TARGET %s OCC=%d" % (w, occ))
    blanked = re.sub(r"\b%s\b" % re.escape(w), "____", sent, count=1, flags=re.I)
    if "____" not in blanked or "____" == sent:
        errors.append("SCENE NOT BLANKED %s" % w)
    if not re.search(r"第\s*\d+\s*个义项", r["sceneCN"]):
        errors.append("SCENECN NO SENSE REF %s" % w)

    # 中文字段扫描
    cn = [(k, r[k]) for k in CN_FIELDS]
    cn.append(("dict_text", r["dict_mnemonic"]["text"]))
    cn.append(("sensesIntro.cn", r["sensesIntro"]["cn"]))
    cn.append(("ety_intro.cn", r["etymology"]["intro"]["cn"]))
    cn.append(("map_core.cn", sm["core"]["cn"]))
    cn.append(("sim_note.cn", r["similar"]["note"]["cn"]))
    cn.append(("mn_intro.cn", r["mnemonics"]["normalIntro"]["cn"]))
    cn.append(("affix_intro.cn", r["affixes"]["intro"]["cn"]))
    cn.append(("affix_latin_intro.cn", r["affixes"]["latinIntro"]["cn"]))
    for i, s in enumerate(r["senses"], 1):
        for k in ("titleCN", "definitionCN", "exampleCN", "whyCN"):
            cn.append(("senses[%d].%s" % (i, k), s[k]))
    for i, e in enumerate(r["examples"], 1):
        cn.append(("examples[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["normal"], 1):
        cn.append(("mnormal[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["abstract"], 1):
        cn.append(("mabstract[%d].cn" % i, e["cn"]))
    for i, b in enumerate(sm["branches"], 1):
        cn.append(("branch[%d].cn" % i, b["cn"]))
    for i, e in enumerate(r["etymology"]["items"], 1):
        cn.append(("ety[%d].cn" % i, e["cn"]))
    for i, g in enumerate(r["similar"]["groups"], 1):
        for j, x in enumerate(g["entries"], 1):
            cn.append(("similar[%d][%d].definitionCN" % (i, j), x.get("definitionCN", "")))
    for i, e in enumerate(r["affixes"]["items"], 1):
        cn.append(("affix[%d].meaningCN" % i, e["meaningCN"]))
        cn.append(("affix[%d].exampleCN" % i, e["exampleCN"]))
    for name, v in cn:
        if LATIN.search(v or ""):
            errors.append("CN LATIN %s.%s: %s" % (w, name, v))
        if CYR.search(v or ""):
            errors.append("CN CYRILLIC %s.%s: %s" % (w, name, v))
        if any(ch in TRAD for ch in (v or "")):
            errors.append("TRAD CHAR %s.%s: %s" % (w, name, v))

    # pos/forms 基本完整性
    if not r["pos"] or not r["collocations"] or not r["forms"] or not r["derivatives"]:
        errors.append("LIST EMPTY %s" % w)
    if len(r["collocations"]) < 4:
        errors.append("COLLOC TOO FEW %s" % w)
    if len(r["mnemonics"]["normal"]) != 5 or len(r["mnemonics"]["abstract"]) != 3:
        errors.append("MN COUNT %s" % w)
    if len(r["examples"]) != 3:
        errors.append("EXAMPLES COUNT %s" % w)

# 全库重名
allwords = {}
files = [f for f in glob.glob(os.path.join(HERE, "toefl-core-5000-*.json"))
         if os.path.basename(f) != "toefl-core-5000-0236.json"
         and "diagnostic" not in f and "duplicate" not in f and "meta" not in f]
bad_files = 0
for f in files:
    try:
        d = json.load(open(f, encoding="utf-8"))
    except Exception:
        bad_files += 1
        continue
    if isinstance(d, list):
        for rec in d:
            if isinstance(rec, dict) and "word" in rec:
                allwords.setdefault(rec["word"].strip().lower(), []).append(os.path.basename(f))

ours = [w.strip().lower() for w in seen_words]
dup = {w: allwords[w] for w in ours if w in allwords}
if len(set(ours)) != len(ours):
    errors.append("INTERNAL DUP %s" % ours)

print("FILE:", OUT)
print("BYTES:", os.path.getsize(OUT))
print("WORDS:", len(data), "SENSES:", sum(len(r["senses"]) for r in data))
print("LIB FILES:", len(files), "LIB UNIQUE:", len(allwords), "UNPARSEABLE:", bad_files)
print("OUR DUPLICATES:", dup)
print("ERRORS:", len(errors))
for e in errors:
    print(" -", e)
sys.exit(1 if errors else 0)
