# 0237 批次构建与校验（临时文件，批次号唯一）
import json, re, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _tmp_0237_p1 as p1
import _tmp_0237_p2 as p2
import _tmp_0237_p3 as p3

RECORDS = p1.RECORDS + p2.RECORDS + p3.RECORDS
TARGET = os.path.join(os.path.dirname(os.path.abspath(__file__)), "toefl-core-5000-0237.json")

KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene", "sceneCN",
        "pos", "collocations", "forms", "derivatives", "senses", "etymology", "similar", "mnemonics",
        "examples", "dict_mnemonic", "root", "sensesIntro", "semanticMap", "affixes"]
SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

LATIN_RE = re.compile(r"[A-Za-z]")
CN_RE = re.compile(r"[\u4e00-\u9fff]")
CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")


def fail(msgs, tag, msg):
    msgs.append("[%s] %s" % (tag, msg))


def is_phrase(word):
    return " " in word


def check(records):
    msgs = []
    soft_cn_fields = {"root", "dict_text", "definitionCN", "whyCN", "exampleCN", "cn"}
    if not isinstance(records, list):
        return ["顶层不是数组"]
    if len(records) != 15:
        fail(msgs, "顶层", "记录数 %d != 15" % len(records))

    seen = set()
    for r in records:
        w = r.get("word", "?")
        if w in seen:
            fail(msgs, w, "本批内部重名")
        seen.add(w)

        if list(r.keys()) != KEYS:
            fail(msgs, w, "顶层键序不一致: 缺失 %s 多余 %s 错序 %s" % (
                [k for k in KEYS if k not in r], [k for k in r if k not in KEYS],
                [i for i, k in enumerate(r.keys()) if k != KEYS[i] if i < len(KEYS)]))

        for k, v in r.items():
            if k in ("etymology", "sensesIntro", "semanticMap", "affixes", "similar", "mnemonics"):
                continue
            if not v:
                fail(msgs, w, "空值字段 %s" % k)

        # 空串/undefined/null/零宽字符扫描
        def scan(obj, path):
            if isinstance(obj, str):
                if obj.strip() == "":
                    fail(msgs, w, "空串 %s" % path)
                if "undefined" in obj or "null" in obj.lower():
                    fail(msgs, w, "可疑占位串 %s" % path)
                if any(ch in obj for ch in ("\u200b", "\u200c", "\u200d", "\ufeff")):
                    fail(msgs, w, "零宽字符 %s" % path)
                if "\ufffd" in obj:
                    fail(msgs, w, "乱码字符 %s" % path)
            elif isinstance(obj, dict):
                for kk, vv in obj.items():
                    scan(vv, path + "." + kk)
            elif isinstance(obj, list):
                for i, vv in enumerate(obj):
                    scan(vv, path + "[%d]" % i)
        scan(r, w)

        # 中英混杂检查
        def walk(obj, path, zh_field):
            last = path.split(".")[-1]
            if isinstance(obj, str):
                if path.endswith(".scene"):
                    return
                if path.endswith(".label"):
                    return
                if path.endswith(".note"):
                    return
                if zh_field:
                    letters = LATIN_RE.findall(obj)
                    if last not in soft_cn_fields and letters:
                        fail(msgs, w, "中文字段含英文 %s: %s" % (path, obj[:40]))
                    if last in soft_cn_fields:
                        if re.search(r"[A-Za-z]+(?:[ '\-][A-Za-z]+){2,}", obj):
                            fail(msgs, w, "中文字段英文短语过长 %s" % path)
                else:
                    if CN_RE.search(obj):
                        fail(msgs, w, "英文字段含中文 %s: %s" % (path, obj[:40]))
            elif isinstance(obj, dict):
                for kk, vv in obj.items():
                    walk(vv, path + "." + kk, zh_field or kk in ("cn", "zh", "meaningCN", "definitionCN", "titleCN", "exampleCN", "whyCN", "sceneCN", "definition_zh", "core_image", "text", "root"))
            elif isinstance(obj, list):
                for i, vv in enumerate(obj):
                    walk(vv, path + "[%d]" % i, zh_field)
        walk(r, w, False)

        # senses
        s = r.get("senses", [])
        if not (8 <= len(s) <= 10):
            fail(msgs, w, "义项数 %d 不在 8-10" % len(s))
        for i, sn in enumerate(s):
            if list(sn.keys()) != SENSE_KEYS:
                fail(msgs, w, "义项 %d 键不一致" % (i + 1))
            if sn.get("no") != "%02d" % (i + 1):
                fail(msgs, w, "义项编号不连续 %s" % sn.get("no"))
            for kk in SENSE_KEYS:
                if not sn.get(kk):
                    fail(msgs, w, "义项 %s 缺 %s" % (sn.get("no"), kk))
            ex = sn.get("example", "")
            if r["word"].lower() not in ex.lower():
                fail(msgs, w, "义项 %s 例句不含目标短语: %s" % (sn.get("no"), ex[:60]))

        # 语义地图
        sm = r.get("semanticMap", {})
        chain = sm.get("chain", [])
        branches = sm.get("branches", [])
        if len(chain) != 6:
            fail(msgs, w, "语义链环数 %d != 6" % len(chain))
        if len(branches) != 5:
            fail(msgs, w, "分支数 %d != 5" % len(branches))
        nums = {int(sn["no"]) for sn in s}
        used = set()
        for b in branches:
            if not b.get("en") or not b.get("cn"):
                fail(msgs, w, "分支缺说明")
            parts = re.split(r"[·,\s]+", b.get("senses", "").strip())
            for p2_ in [p for p in parts if p]:
                if not p2_.isdigit():
                    fail(msgs, w, "分支编号非法 %s" % b.get("senses"))
                    continue
                n = int(p2_)
                if n not in nums:
                    fail(msgs, w, "分支回指失效 %s" % b.get("senses"))
                used.add(n)
        if not used:
            fail(msgs, w, "分支未回指任何义项")

        # 词源
        et = r.get("etymology", {})
        items = et.get("items", [])
        if not (5 <= len(items) <= 6):
            fail(msgs, w, "词源段数 %d 不在 5-6" % len(items))
        for it in items:
            if list(it.keys()) != ["era", "en", "cn"]:
                fail(msgs, w, "词源段键不一致")
            if not it.get("era", "").isupper():
                fail(msgs, w, "词源年代标签不是大写 %s" % it.get("era"))
            if not it.get("en") or not it.get("cn"):
                fail(msgs, w, "词源段缺内容")

        # 相似词
        sim = r.get("similar", {})
        groups = sim.get("groups", [])
        if len(groups) != 2 or [g.get("heading") for g in groups] != ["LOOK-ALIKE", "NEAR MEANING"]:
            fail(msgs, w, "similar 组结构异常")
        for g in groups:
            if len(g.get("entries", [])) < 2:
                fail(msgs, w, "similar 组条目过少 %s" % g.get("heading"))
            for e in g.get("entries", []):
                for kk in ("word", "ipa", "tag", "definition", "definitionCN"):
                    if not e.get(kk):
                        fail(msgs, w, "similar 条目缺 %s" % kk)

        # 联想
        mn = r.get("mnemonics", {})
        if len(mn.get("normal", [])) != 5:
            fail(msgs, w, "正常联想数 %d != 5" % len(mn.get("normal", [])))
        if len(mn.get("abstract", [])) != 3:
            fail(msgs, w, "抽象联想数 %d != 3" % len(mn.get("abstract", [])))
        for x in mn.get("normal", []) + mn.get("abstract", []):
            if not x.get("en") or not x.get("cn"):
                fail(msgs, w, "联想缺中英")

        # 例句
        exs = r.get("examples", [])
        if len(exs) != 3:
            fail(msgs, w, "例句数 %d != 3" % len(exs))
        for e in exs:
            if r["word"].lower() not in e.get("en", "").lower():
                fail(msgs, w, "例句不含目标短语: %s" % e.get("en", "")[:60])

        # 搭配与变形
        if not (4 <= len(r.get("collocations", [])) <= 7):
            fail(msgs, w, "搭配数不在 4-7")
        if len(r.get("forms", [])) < 4:
            fail(msgs, w, "变形条数不足")
        if len(r.get("derivatives", [])) < 4:
            fail(msgs, w, "派生词条数不足")

        # 词缀
        af = r.get("affixes", {})
        ai = af.get("items", [])
        if not (8 <= len(ai) <= 12):
            fail(msgs, w, "词缀条目数 %d 不在 8-12" % len(ai))
        for it in ai:
            for kk in ("word", "structure", "meaning", "meaningCN", "example", "exampleCN"):
                if not it.get(kk):
                    fail(msgs, w, "词缀条目缺 %s" % kk)
        if not af.get("derivatives"):
            fail(msgs, w, "派生词列表为空")
        if not af.get("latinIntro", {}).get("en"):
            fail(msgs, w, "词缀拉丁说明为空")

        # scene 挖空自测
        scene = r["scene"]
        cn_prefix = re.split(r"[A-Za-z]", scene)[0]
        if LATIN_RE.search(cn_prefix) or re.search(r"[0-9]", cn_prefix):
            fail(msgs, w, "场景中文铺垫含字母或数字")
        if not CJK_RE.search(cn_prefix):
            fail(msgs, w, "场景缺少中文铺垫")
        en_part = scene[len(cn_prefix):]
        if CN_RE.search(en_part):
            fail(msgs, w, "场景英文句含中文")
        cnt = en_part.lower().count(r["word"].lower())
        if cnt != 1:
            fail(msgs, w, "场景目标短语出现 %d 次（应为 1）" % cnt)
        if not re.search(r"[.!?]\s*$", en_part.strip()):
            fail(msgs, w, "场景英文句无句末标点")
        if "第" not in r["sceneCN"] or "个义项" not in r["sceneCN"]:
            fail(msgs, w, "sceneCN 未引用义项")

        # 英文句挖空模拟：把短语整段替换为空白后仍保留可读骨架
        blank = re.sub(re.escape(r["word"]), "____", en_part, flags=re.I)
        if "____" not in blank:
            fail(msgs, w, "挖空失败")

    return msgs


def main():
    msgs = check(RECORDS)
    if msgs:
        print("CHECK FAILED (%d)" % len(msgs))
        for m in msgs[:60]:
            print(m)
        sys.exit(1)
    with open(TARGET, "w", encoding="utf-8") as fh:
        json.dump(RECORDS, fh, ensure_ascii=False, indent=1)
    data2 = json.load(open(TARGET, encoding="utf-8"))
    msgs2 = check(data2)
    size = os.path.getsize(TARGET)
    print("PASS: %d records, %d bytes" % (len(data2), size))
    print("senses total:", sum(len(r["senses"]) for r in data2))
    print("second parse issues:", len(msgs2))
    if msgs2:
        for m in msgs2[:20]:
            print(m)
        sys.exit(1)


if __name__ == "__main__":
    main()
