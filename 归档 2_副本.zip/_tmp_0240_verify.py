# 0240 批次校验脚本（临时文件，批次号唯一，不参与运行时）
import json, glob, os, re, sys

OUT = "books/prepared/toefl-core-5000-0240.json"
ORDER = ["for instance", "for example", "moreover", "thus", "prior to", "subsequent to"]
KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image", "scene", "sceneCN", "pos",
        "collocations", "forms", "derivatives", "senses", "etymology", "similar", "mnemonics", "examples",
        "dict_mnemonic", "root", "sensesIntro", "semanticMap", "affixes"]
SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

errors = []
with open(OUT, encoding="utf-8") as fh:
    raw = fh.read()
data = json.loads(raw)

if not isinstance(data, list):
    errors.append("TOP NOT ARRAY: %s" % type(data))
if len(data) != 6:
    errors.append("TOP LEN %d" % len(data))
if [r.get("word") for r in data] != ORDER:
    errors.append("ORDER MISMATCH: %s" % [r.get("word") for r in data])


def forms_of(word):
    forms = {word, word + "s", word + "es", word + "ed", word + "ing", word + "d"}
    if word.endswith("e"):
        forms.add(word[:-1] + "ing")
    forms.add(word + word[-1] + "ing")
    forms.add(word + word[-1] + "ed")
    return forms


def empty_scan(obj, path, out):
    if obj is None:
        out.append("NULL " + path)
    elif isinstance(obj, str):
        if not obj.strip():
            out.append("BLANKSTR " + path)
    elif isinstance(obj, (list, tuple)):
        if not obj:
            out.append("EMPTYLIST " + path)
        for i, v in enumerate(obj):
            empty_scan(v, "%s[%d]" % (path, i), out)
    elif isinstance(obj, dict):
        if not obj:
            out.append("EMPTYDICT " + path)
        for k, v in obj.items():
            empty_scan(v, "%s.%s" % (path, k), out)


CN_FIELDS = ("definition_zh", "core_image", "sceneCN", "root")
TRAD = set("個們來時說會發現這樣為與學問長間開對從無觀點後裡麼應該還讓給過於將種號稱據處實際體變導遊歷產業務區塊圖網絡資訊數")

uncertain = []

for r in data:
    w = r["word"]
    if list(r.keys()) != KEYS:
        errors.append("KEYS %s" % w)
    if len(r["senses"]) < 8 or len(r["senses"]) > 10:
        errors.append("SENSES COUNT %s %d" % (w, len(r["senses"])))
    for i, s in enumerate(r["senses"], 1):
        if list(s.keys()) != SENSE_KEYS:
            errors.append("SENSE KEYS %s %d" % (w, i))
        if s["no"] != "%02d" % i:
            errors.append("SENSE NO %s %d %s" % (w, i, s["no"]))
        fs = forms_of(w)
        if not any(re.search(r"\b%s\b" % re.escape(x), s["example"], flags=re.I) for x in fs):
            errors.append("SENSE EXAMPLE NO WORD %s %d" % (w, i))

    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        errors.append("CHAIN %s %d" % (w, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        errors.append("BRANCH %s %d" % (w, len(sm["branches"])))
    refs = []
    for b in sm["branches"]:
        nums = [int(x) for x in re.findall(r"\d+", b["senses"])]
        if not nums:
            errors.append("BRANCH NO REF %s" % w)
        refs.extend(nums)
        for n in nums:
            if not (1 <= n <= len(r["senses"])):
                errors.append("BRANCH BAD %s %s" % (w, b["senses"]))
    if len(refs) != len(set(refs)):
        errors.append("BRANCH DUP REF %s %s" % (w, refs))

    if not (5 <= len(r["etymology"]["items"]) <= 6):
        errors.append("ETY %s %d" % (w, len(r["etymology"]["items"])))

    if len(r["similar"]["groups"]) != 2:
        errors.append("SIMILAR GROUPS %s" % w)
    for g in r["similar"]["groups"]:
        for x in g["entries"]:
            if x["word"].lower() == w.lower():
                errors.append("SIMILAR SELF %s" % w)
    seen = set()
    for x in r["derivatives"]:
        key = (x["word"].lower(), x["pos"])
        if key in seen:
            errors.append("DERIV DUP %s %s %s" % (w, x["word"], x["pos"]))
        seen.add(key)

    if not (8 <= len(r["affixes"]["items"]) <= 12):
        errors.append("AFFIX ITEMS %s %d" % (w, len(r["affixes"]["items"])),)
    if len(r["examples"]) != 3:
        errors.append("EXAMPLES %s %d" % (w, len(r["examples"])))
    if len(r["mnemonics"]["normal"]) != 5:
        errors.append("MN NORMAL %s %d" % (w, len(r["mnemonics"]["normal"])))
    if len(r["mnemonics"]["abstract"]) != 3:
        errors.append("MN ABSTRACT %s %d" % (w, len(r["mnemonics"]["abstract"])))

    empties = []
    empty_scan(r, w, empties)
    errors.extend(e for e in empties if ".affixes.latinEntries" not in e)

    # scene 自测：与 sceneSentence + buildSpeakBlank 同思路
    scene = r["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        errors.append("SCENE NO EN %s" % w)
        continue
    pre, sent = scene[:m.start()], scene[m.start():]
    if re.search(r"[A-Za-z0-9]", pre):
        errors.append("PREAMBLE LATIN/DIGIT %s" % w)
    ordered = sorted(forms_of(w), key=len, reverse=True)
    used = None
    for form in ordered:
        pat = r"\b%s\b" % re.escape(form)
        if re.search(pat, sent, flags=re.I):
            used = form
            break
    if used is None:
        errors.append("SCENE NO TARGET %s" % w)
    else:
        occ = len(re.findall(r"\b%s\b" % re.escape(used), sent, flags=re.I))
        if occ != 1:
            errors.append("SCENE TARGET %s OCC=%d form=%s" % (w, occ, used))
    if not re.search(r"第\s*\d+\s*个义项", r["sceneCN"]):
        errors.append("SCENECN NO SENSE REF %s: %s" % (w, r["sceneCN"]))

    # 中文字段禁拉丁字母、禁繁体
    cn = [(k, r[k]) for k in CN_FIELDS]
    cn.append(("dict_text", r["dict_mnemonic"]["text"]))
    cn.append(("sensesIntro.cn", r["sensesIntro"]["cn"]))
    for x in r["pos"]:
        cn.append(("pos.zh", x["zh"]))
    for x in r["collocations"]:
        cn.append(("colloc.zh", x["zh"]))
    for x in r["forms"]:
        cn.append(("forms.label", x["label"]))
    for x in r["derivatives"]:
        cn.append(("deriv.zh", x["zh"]))
    for i, s in enumerate(r["senses"], 1):
        for k in ("titleCN", "definitionCN", "exampleCN", "whyCN"):
            cn.append(("senses[%d].%s" % (i, k), s[k]))
    for i, e in enumerate(r["examples"], 1):
        cn.append(("examples[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["normal"], 1):
        cn.append(("mnormal[%d].cn" % i, e["cn"]))
    for i, e in enumerate(r["mnemonics"]["abstract"], 1):
        cn.append(("mabstract[%d].cn" % i, e["cn"]))
    for i, b in enumerate(sm["branches"], 1):
        cn.append(("branch[%d].cn" % i, b["cn"]))
    cn.append(("map.core.cn", sm["core"]["cn"]))
    cn.append(("mn.intro.cn", r["mnemonics"]["normalIntro"]["cn"]))
    for i, e in enumerate(r["etymology"]["items"], 1):
        cn.append(("ety[%d].cn" % i, e["cn"]))
    cn.append(("ety.intro.cn", r["etymology"]["intro"]["cn"]))
    for x in r["similar"]["note"].values():
        pass
    cn.append(("similar.note.cn", r["similar"]["note"]["cn"]))
    for i, g in enumerate(r["similar"]["groups"], 1):
        for j, x in enumerate(g["entries"], 1):
            cn.append(("similar[%d][%d].defCN" % (i, j), x["definitionCN"]))
    for i, e in enumerate(r["affixes"]["items"], 1):
        cn.append(("affix[%d].meaningCN" % i, e["meaningCN"]))
        cn.append(("affix[%d].exampleCN" % i, e["exampleCN"]))
    for f, v in cn:
        if re.search(r"[A-Za-z]", v or ""):
            errors.append("CN LATIN %s.%s: %s" % (w, f, v))
        if any(ch in TRAD for ch in v or ""):
            errors.append("TRAD CHAR %s.%s: %s" % (w, f, v))

    # 来源不确定标注清点（按字段实际文字统计）
    blob = json.dumps(r["etymology"], ensure_ascii=False)
    if "来源不确定" in blob or "首见年代不确定" in blob or "source uncertain" in blob:
        uncertain.append(w)

# 落盘后二次解析
with open(OUT, encoding="utf-8") as fh:
    data2 = json.loads(fh.read())
if data2 != data:
    errors.append("REPARSE MISMATCH")

# 全库唯一/重复
allwords = {}
files = [x for x in glob.glob("books/prepared/toefl-core-5000-*.json") if "0240" not in x]
bad_files = 0
for x in files:
    try:
        d = json.load(open(x, encoding="utf-8"))
    except Exception:
        bad_files += 1
        continue
    if isinstance(d, list):
        for rec in d:
            if isinstance(rec, dict) and "word" in rec:
                allwords.setdefault(rec["word"].lower(), []).append(os.path.basename(x))
ours = [r["word"].lower() for r in data]
dup = {k: allwords[k] for k in ours if k in allwords}

print("FILE:", os.path.abspath(OUT))
print("BYTES:", os.path.getsize(OUT))
print("WORDS:", len(data), [r["word"] for r in data])
print("SENSES TOTAL:", sum(len(r["senses"]) for r in data))
print("UNCERTAIN TAGGED:", uncertain)
print("LIB FILES:", len(files), "LIB UNIQUE:", len(allwords), "UNPARSEABLE:", bad_files)
print("OUR DUPLICATES:", dup)
print("ERRORS:", len(errors))
for e in errors:
    print(" -", e)
sys.exit(1 if errors else 0)
