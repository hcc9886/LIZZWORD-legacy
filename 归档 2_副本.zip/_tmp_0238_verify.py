# -*- coding: utf-8 -*-
"""批次 0238 全量校验：结构、义项、分支、词源、空值、场景挖空、重名。"""

import glob
import json
import os
import re
import sys

BASE = "/Users/hcc/Desktop/LIZZWORD/books/prepared"
TARGET = os.path.join(BASE, "toefl-core-5000-0238.json")

TOP_KEYS = ["word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image",
            "scene", "sceneCN", "pos", "collocations", "forms", "derivatives", "senses",
            "etymology", "similar", "mnemonics", "examples", "dict_mnemonic", "root",
            "sensesIntro", "semanticMap", "affixes"]
SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

errors = []
warnings = []


def err(msg):
    errors.append(msg)


raw = open(TARGET, encoding="utf-8").read()
data = json.loads(raw)
print("bytes", len(raw.encode("utf-8")))
if not isinstance(data, list):
    err("顶层不是数组")
if len(data) != 15:
    err("条目数不是 15: %s" % len(data))

# ---------- 空值扫描 ----------
def scan_empty(node, path):
    if isinstance(node, dict):
        for k, v in node.items():
            scan_empty(v, path + "." + str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            scan_empty(v, path + "[%d]" % i)
    elif isinstance(node, str):
        if node.strip() == "":
            err("空串 %s" % path)
        if node.strip().lower() in ("undefined", "null", "none", "n/a", "tbd"):
            err("占位串 %s = %r" % (path, node))
        if "\u200b" in node or "\ufeff" in node:
            err("零宽字符 %s" % path)
    elif node is None:
        err("null %s" % path)


scan_empty(data, "$")

# ---------- 结构 ----------
def check_sense_nums(w, expected_n):
    nums = [s["no"] for s in w["senses"]]
    want = ["%02d" % (i + 1) for i in range(expected_n)]
    if nums != want:
        err("%s 义项编号不连续: %s" % (w["word"], nums))


for idx, w in enumerate(data):
    if list(w.keys()) != TOP_KEYS:
        err("%s 顶层键序不符" % w["word"])
    word = w["word"]
    n = len(w["senses"])
    if not 8 <= n <= 10:
        err("%s 义项数 %d 越界" % (word, n))
    for s in w["senses"]:
        if list(s.keys()) != SENSE_KEYS:
            err("%s 义项 %s 键序不符" % (word, s.get("no")))
    check_sense_nums(w, n)

    # 分支
    chain = w["semanticMap"]["chain"]
    if len(chain) != 6:
        err("%s 主链不是 6 环" % word)
    branches = w["semanticMap"]["branches"]
    if len(branches) != 5:
        err("%s 分支数 %d" % (word, len(branches)))
    seen = []
    for b in branches:
        nums = [x.strip() for x in b["senses"].split("·")]
        for x in nums:
            if not re.fullmatch(r"\d{2}", x):
                err("%s 分支编号格式异常 %r" % (word, b["senses"]))
                continue
            if x not in [s["no"] for s in w["senses"]]:
                err("%s 分支回指悬空 %s" % (word, x))
            seen.append(x)
    if len(seen) != len(set(seen)):
        err("%s 分支编号重复" % word)
    for s in w["senses"]:
        if s["no"] not in seen:
            warnings.append("%s 义项 %s 未被分支覆盖" % (word, s["no"]))
    if sorted(seen) != sorted(["%02d" % (i + 1) for i in range(n)]):
        warnings.append("%s 分支未覆盖全部义项: %s" % (word, seen))

    # 词源
    et = w["etymology"]
    if len(et["items"]) not in (5, 6):
        err("%s 词源段数 %d" % (word, len(et["items"])))
    for it in et["items"]:
        if not it["era"] or not it["era"].isupper():
            err("%s era 未大写: %r" % (word, it["era"]))

    # 数量类字段
    if not 4 <= len(w["collocations"]) <= 7:
        err("%s 搭配数 %d" % (word, len(w["collocations"])))
    if not 8 <= len(w["affixes"]["items"]) <= 12:
        err("%s 词缀条目 %d" % (word, len(w["affixes"]["items"])))
    if len(w["mnemonics"]["normal"]) != 5 or len(w["mnemonics"]["abstract"]) != 3:
        err("%s 联想条数不符" % word)
    if len(w["examples"]) != 3:
        err("%s 例句数 %d" % (word, len(w["examples"])))
    if len(w["derivatives"]) < 4:
        err("%s 派生词不足" % word)
    if len(w["forms"]) < 4:
        err("%s 变形不足" % word)
    if not all(g["heading"] in ("LOOK-ALIKE", "NEAR MEANING") and len(g["entries"]) >= 5
               for g in w["similar"]["groups"]) or len(w["similar"]["groups"]) != 2:
        err("%s similar 分组不符" % word)

# ---------- 场景挖空 ----------
def js_forms(word):
    forms = {word, word + "s", word + "es", word + "ed", word + "ing", word + "d"}
    if word.endswith("e"):
        forms.add(word[:-1] + "ing")
    last = word[-1]
    forms.add(word + last + "ing")
    forms.add(word + last + "ed")
    return sorted(forms, key=len, reverse=True)


def blank(scene, word):
    for form in js_forms(word):
        m = re.search(r"\b" + re.escape(form) + r"\b", scene, re.I)
        if m:
            return scene[:m.start()] + "____" + scene[m.end():], form
    return scene, word


for w in data:
    word = w["word"]
    scene = w["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        err("%s 场景缺英文句" % word)
        continue
    prefix, sentence = scene[:m.start()], scene[m.start():].strip()
    if re.search(r"[A-Za-z0-9]", prefix):
        err("%s 场景中文铺垫含拉丁字母或数字: %r" % (word, prefix))
    count = len(re.findall(r"\b" + re.escape(word) + r"\b", sentence, re.I))
    if count != 1:
        err("%s 场景中目标短语出现 %d 次" % (word, count))
    after, used = blank(" " + sentence, word)
    if "____" not in after:
        err("%s 场景无法挖空" % word)
    if used.lower() != word.lower():
        warnings.append("%s 挖空命中形态 %r" % (word, used))

    note = w["sceneCN"]
    mm = re.search(r"第\s*(\d+)\s*个义项", note)
    if not mm:
        err("%s sceneCN 缺义项引用" % word)
    else:
        no = int(mm.group(1))
        if not 1 <= no <= len(w["senses"]):
            err("%s sceneCN 义项编号越界 %d" % (word, no))
    if not note.startswith("这里指"):
        warnings.append("%s sceneCN 未以「这里指」开头" % word)

    for ex in w["examples"]:
        if len(re.findall(r"\b" + re.escape(word) + r"\b", ex["en"], re.I)) < 1:
            err("%s 例句缺目标短语: %s" % (word, ex["en"]))

# ---------- 中文字段拉丁字母抽查 ----------
# 严格区：叙述性中文字段不得夹英文字面；词源/词缀/联想/近义对照允许拉丁希腊引文与对照词
STRICT_CN_FIELDS = ("definition_zh", "core_image", "sceneCN")
for w in data:
    for s in w["senses"]:
        for k in ("titleCN", "definitionCN", "exampleCN"):
            if re.search(r"[A-Za-z]", s[k]):
                err("%s 义项 %s 中文字段含拉丁字母: %s" % (w["word"], s["no"], k))
    for k in STRICT_CN_FIELDS:
        if re.search(r"[A-Za-z]", w[k]):
            err("%s %s 含拉丁字母" % (w["word"], k))
    for c in w["collocations"]:
        if re.search(r"[A-Za-z]", c["zh"]):
            err("%s 搭配中文含拉丁字母: %s" % (w["word"], c["phrase"]))
    for d in w["derivatives"]:
        if re.search(r"[A-Za-z]", d["zh"]):
            err("%s 派生词说明含拉丁字母: %s" % (w["word"], d["word"]))
    for e in w["examples"]:
        if re.search(r"[A-Za-z]", e["cn"]):
            err("%s 例句译文含拉丁字母" % w["word"])
    if re.search(r"[A-Za-z]", w["sensesIntro"]["cn"]):
        err("%s sensesIntro 中文含拉丁字母" % w["word"])
    if re.search(r"[A-Za-z]", w["mnemonics"]["normalIntro"]["cn"]):
        err("%s 联想引言中文含拉丁字母" % w["word"])
    for it in w["affixes"]["items"]:
        if re.search(r"[A-Za-z]", it["meaningCN"]):
            err("%s 词缀中文释义含拉丁字母" % w["word"])
    for g in w["similar"]["groups"]:
        for e in g["entries"]:
            if re.search(r"[A-Za-z]", e["definitionCN"]):
                err("%s 近义说明中文含拉丁字母: %s" % (w["word"], e["word"]))
    if re.search(r"[A-Za-z]", w["similar"]["note"]["cn"]):
        err("%s similar 说明中文含拉丁字母" % w["word"])
    # 引用型字段只提示
    for s in w["senses"]:
        if re.search(r"[A-Za-z]", s["whyCN"]):
            warnings.append("%s 义项 %s whyCN 含拉丁引文" % (w["word"], s["no"]))
    for mn in w["mnemonics"]["normal"] + w["mnemonics"]["abstract"]:
        if re.search(r"[A-Za-z]", mn["cn"]):
            warnings.append("%s 联想中文含拉丁引文" % w["word"])
            break
    for it in w["affixes"]["items"]:
        if re.search(r"[A-Za-z]", it["exampleCN"]):
            warnings.append("%s 词缀示例译文含拉丁引文" % w["word"])
            break

# ---------- 全库重名 ----------
allwords = {}
for f in glob.glob(os.path.join(BASE, "toefl-core-5000-*.json")):
    if "duplicate" in os.path.basename(f) or "0238" in os.path.basename(f):
        continue
    try:
        d = json.load(open(f, encoding="utf-8"))
    except Exception:
        continue
    if not isinstance(d, list):
        continue
    for e in d:
        if isinstance(e, dict) and "word" in e:
            allwords.setdefault(e["word"], []).append(os.path.basename(f))
dups = []
for w in data:
    if w["word"] in allwords:
        dups.append((w["word"], allwords[w["word"]]))

# 本文件内部重复
internal = [w["word"] for w in data]
if len(internal) != len(set(internal)):
    err("本批内部重名")

# ---------- 存疑来源统计 ----------
uncertain = []
for w in data:
    et = w["etymology"]
    blob = et["intro"]["en"] + et["intro"]["cn"] + " ".join(i["en"] + i["cn"] for i in et["items"]) + w["root"]
    if ("来源不确定" in blob or "source uncertain" in blob or "origin is uncertain" in blob
            or "来源存疑" in blob):
        uncertain.append(w["word"])

print("entries", len(data))
print("senses_total", sum(len(w["senses"]) for w in data))
print("unique_in_file", len(set(internal)))
print("library_unique", len(set(allwords) | set(internal)))
print("library_duplicates", len(dups))
print("outside_conflicts", dups)
print("uncertain", uncertain)
print("WARNINGS", len(warnings))
for x in warnings[:20]:
    print("  warn:", x)
print("ERRORS", len(errors))
for x in errors[:40]:
    print("  err:", x)
sys.exit(1 if errors else 0)
