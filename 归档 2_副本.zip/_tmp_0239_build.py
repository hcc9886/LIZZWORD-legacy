# 0239 批次构建与全量校验（临时文件，批次号唯一，不参与运行时）
import json
import re
import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tmp_0239_lib import KEYS, SENSE_KEYS

import _tmp_0239_p1 as p1
import _tmp_0239_p2 as p2
import _tmp_0239_p3 as p3
import _tmp_0239_p4 as p4

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "toefl-core-5000-0239.json")

records = p1.RECORDS + p2.RECORDS + p3.RECORDS + p4.RECORDS

errors = []
warnings = []

def err(msg):
    errors.append(msg)

# ---------- 1. structure ----------
EXPECTED_WORDS = [
    "by means of", "for the purpose of", "in the course of", "in the process of",
    "on the basis of", "with regard to", "to a certain extent", "as a result",
    "in turn", "in particular", "in general", "in essence", "in principle",
    "on the other hand", "in other words",
]

if [r["word"] for r in records] != EXPECTED_WORDS:
    err("词序或词数与预期不符: %s" % [r["word"] for r in records])

for r in records:
    w = r["word"]
    if list(r.keys()) != KEYS:
        err("%s 顶层键集合或键序不符: %s" % (w, list(r.keys())))
    if len(r["senses"]) < 8 or len(r["senses"]) > 10:
        err("%s 义项数 %d 不在 8-10" % (w, len(r["senses"])))
    nos = []
    for idx, sn in enumerate(r["senses"]):
        if list(sn.keys()) != SENSE_KEYS:
            err("%s 义项 %d 键不符: %s" % (w, idx + 1, list(sn.keys())))
        nos.append(sn["no"])
    if nos != ["%02d" % i for i in range(1, len(nos) + 1)]:
        err("%s 义项编号不连续: %s" % (w, nos))
    etyi = r["etymology"]["items"]
    if len(etyi) < 5 or len(etyi) > 6:
        err("%s 词源段数 %d 不在 5-6" % (w, len(etyi)))
    for e in etyi:
        if not e["era"] or e["era"] != e["era"].upper():
            err("%s 词源 era 非大写: %s" % (w, e["era"]))
    sm = r["semanticMap"]
    if len(sm["chain"]) != 6:
        err("%s 主链环数 %d 不是 6" % (w, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        err("%s 分支数 %d 不是 5" % (w, len(sm["branches"])))
    valid = set("%02d" % i for i in range(1, len(r["senses"]) + 1))
    seen = set()
    for b in sm["branches"]:
        refs = [x.strip() for x in b["senses"].split("·")]
        for x in refs:
            if x not in valid:
                err("%s 分支回指无效: %s" % (w, b["senses"]))
            if x in seen:
                err("%s 分支回指重复: %s" % (w, x))
            seen.add(x)
    if len(r["mnemonics"]["normal"]) != 5 or len(r["mnemonics"]["abstract"]) != 3:
        err("%s 联想条数不符" % w)
    if not (4 <= len(r["collocations"]) <= 7):
        err("%s 搭配数 %d 不在 4-7" % (w, len(r["collocations"])))
    if len(r["examples"]) != 3:
        err("%s 例句数 %d 不是 3" % (w, len(r["examples"])))
    if not (8 <= len(r["affixes"]["items"]) <= 12):
        err("%s 词缀条目 %d 不在 8-12" % (w, len(r["affixes"]["items"])))
    if len(r["similar"]["groups"]) != 2:
        err("%s similar 组数不是 2" % w)
    for g in r["similar"]["groups"]:
        if len(g["entries"]) < 3:
            err("%s similar 组 %s 少于 3 条" % (w, g["heading"]))

# ---------- 2. empty / placeholder scan ----------
BAD_STR = {"", "undefined", "null", "None", "NaN", "TBD", "待补", "占位"}

def walk(node, path, w):
    if isinstance(node, dict):
        for k, v in node.items():
            walk(v, path + "." + k, w)
    elif isinstance(node, list):
        if len(node) == 0:
            return
        for i, v in enumerate(node):
            walk(v, path + "[%d]" % i, w)
    elif isinstance(node, str):
        t = node.strip()
        if t in BAD_STR:
            err("%s 空值或占位: %s" % (w, path))
        if "\u200b" in node or "\u200c" in node or "\u200d" in node or "\ufeff" in node:
            err("%s 零宽字符: %s" % (w, path))
        if re.search(r"\bundefined\b|\bNaN\b", node):
            err("%s 文本含 undefined/NaN: %s" % (w, path))

for r in records:
    walk(r, "", r["word"])

# ---------- 3. Chinese fields must be Chinese only ----------
STRICT_ZH = [
    ("definition_zh",), ("core_image",), ("sceneCN",),
]
LATIN = re.compile(r"[A-Za-z]")

for r in records:
    w = r["word"]
    for f in ["definition_zh", "core_image", "sceneCN"]:
        if LATIN.search(r[f]):
            err("%s 中文字段含拉丁字母: %s -> %s" % (w, f, r[f]))
    if not re.search(r"首见年代|来源不确定", r["root"]):
        err("%s root 未标注年代或来源说明" % w)
    for i, pp in enumerate(r["pos"]):
        if LATIN.search(pp["zh"]):
            err("%s pos.zh 含拉丁字母: %s" % (w, pp["zh"]))
    for cc in r["collocations"]:
        if LATIN.search(cc["zh"]):
            err("%s 搭配释义含拉丁字母: %s" % (w, cc["zh"]))
    for dd in r["derivatives"]:
        if LATIN.search(dd["zh"]):
            err("%s 派生释义含拉丁字母: %s" % (w, dd["zh"]))
    for sn in r["senses"]:
        for f in ["titleCN", "definitionCN", "exampleCN", "whyCN"]:
            if LATIN.search(sn[f]):
                err("%s 义项 %s 含拉丁字母: %s" % (w, f, sn[f]))
    for m in r["mnemonics"]["normal"] + r["mnemonics"]["abstract"]:
        if LATIN.search(m["cn"]):
            err("%s 联想中文含拉丁字母: %s" % (w, m["cn"]))
    if LATIN.search(r["mnemonics"]["normalIntro"]["cn"]):
        err("%s 联想导语中文含拉丁字母" % w)
    for e in r["examples"]:
        if LATIN.search(e["cn"]):
            err("%s 例句译文含拉丁字母: %s" % (w, e["cn"]))
    if LATIN.search(r["dict_mnemonic"]["text"]):
        err("%s 谐音记忆含拉丁字母: %s" % (w, r["dict_mnemonic"]["text"]))
    if LATIN.search(r["sensesIntro"]["cn"]):
        err("%s 义项导语中文含拉丁字母" % w)
    if LATIN.search(r["semanticMap"]["core"]["cn"]):
        err("%s 语义核心中文含拉丁字母" % w)
    for b in r["semanticMap"]["branches"]:
        if LATIN.search(b["cn"]):
            err("%s 语义分支中文含拉丁字母: %s" % (w, b["cn"]))
    for g in r["similar"]["groups"]:
        for e in g["entries"]:
            if LATIN.search(e["definitionCN"]):
                err("%s similar 对照释义含拉丁字母: %s" % (w, e["definitionCN"]))
    for it in r["affixes"]["items"]:
        if LATIN.search(it["meaningCN"]):
            err("%s 词缀释义中文含拉丁字母: %s" % (w, it["meaningCN"]))
        if LATIN.search(it["exampleCN"]):
            err("%s 词缀例句译文含拉丁字母: %s" % (w, it["exampleCN"]))
    for it in r["affixes"]["derivatives"]:
        if LATIN.search(it["zh"]):
            err("%s 词缀派生释义含拉丁字母: %s" % (w, it["zh"]))
    if LATIN.search(r["affixes"]["intro"]["cn"]):
        err("%s 词缀导语中文含拉丁字母" % w)

# ---------- 4. English fields must not contain Chinese ----------
CJK = re.compile(r"[\u4e00-\u9fff]")
for r in records:
    w = r["word"]
    texts = [r["definition_en"], r["semantics"] if "semantics" in r else ""]
    for sn in r["senses"]:
        for f in ["title", "definition", "example", "why"]:
            if CJK.search(sn[f]):
                err("%s 义项英文字段 %s 含中文: %s" % (w, f, sn[f]))
    for e in r["examples"]:
        if CJK.search(e["en"]):
            err("%s 例句原文含中文: %s" % (w, e["en"]))
    for e in r["etymology"]["items"]:
        if CJK.search(e["en"]) or CJK.search(e["era"]):
            err("%s 词源英文段含中文" % w)
    for it in r["affixes"]["items"]:
        if CJK.search(it["meaning"]) or CJK.search(it["example"]):
            err("%s 词缀英文字段含中文: %s" % (w, it["word"]))
    if CJK.search(r["definition_en"]):
        err("%s definition_en 含中文" % w)

# ---------- 5. scene: Chinese lead + one English sentence, phrase once ----------
def scene_split(scene):
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        return None
    return scene[:m.start()], scene[m.start():]

def norm(s):
    return re.sub(r"\s+", " ", s).strip()

for r in records:
    w = r["word"]
    parts = scene_split(r["scene"])
    if not parts:
        err("%s scene 无英文句" % w)
        continue
    lead, eng = parts
    if re.search(r"[A-Za-z0-9]", lead):
        err("%s scene 中文铺垫含拉丁字母或数字: %s" % (w, lead))
    if CJK.search(eng):
        err("%s scene 英文句含中文: %s" % (w, eng))
    pat = r"\b" + re.escape(w) + r"\b"
    cnt = len(re.findall(pat, eng, flags=re.I))
    if cnt != 1:
        err("%s scene 目标短语出现 %d 次（应为 1）" % (w, cnt))
    blanked = re.sub(pat, "____", eng, count=1, flags=re.I)
    if re.search(pat, blanked, flags=re.I):
        err("%s scene 挖空后仍残留目标短语" % w)
    if "____" not in blanked:
        err("%s scene 挖空失败" % w)
    # sceneCN 引用义项号
    if not re.search(r"第\s*(%s)\s*个义项" % "|".join(["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]), r["sceneCN"]):
        err("%s sceneCN 未引用义项编号" % w)

# ---------- 6. every example and sense example contains the phrase ----------
for r in records:
    w = r["word"]
    pat = r"\b" + re.escape(w) + r"\b"
    for i, sn in enumerate(r["senses"]):
        if not re.search(pat, sn["example"], flags=re.I):
            err("%s 义项 %d 例句未含目标短语" % (w, i + 1))
    for i, e in enumerate(r["examples"]):
        if not re.search(pat, e["en"], flags=re.I):
            err("%s 总例句 %d 未含目标短语" % (w, i + 1))

# ---------- 7. duplicate check across all delivered batches ----------
all_files = sorted(glob.glob(os.path.join(os.path.dirname(OUT), "toefl-core-5000-*.json")))
delivered = []
skipped_files = []
for fn in all_files:
    base = os.path.basename(fn)
    if base == "toefl-core-5000-0239.json":
        continue
    if "diagnostic" in base or "meta" in base:
        continue
    try:
        data = json.load(open(fn, encoding="utf-8"))
    except Exception:
        skipped_files.append(base)
        continue
    if not isinstance(data, list):
        skipped_files.append(base)
        continue
    for rec0 in data:
        if isinstance(rec0, dict) and isinstance(rec0.get("word"), str):
            delivered.append((rec0["word"], base))

mine = [r["word"] for r in records]
dups = [(w, f) for w, f in delivered if w in mine]
unique_all = len(set([w for w, _ in delivered] + mine))

# ---------- 8. write & re-parse ----------
if errors:
    print("VALIDATION FAILED BEFORE WRITE")
    for e in errors:
        print(" -", e)
    sys.exit(1)

payload = json.dumps(records, ensure_ascii=False, indent=2)
with open(OUT, "w", encoding="utf-8") as fh:
    fh.write(payload)
    fh.write("\n")

raw = open(OUT, encoding="utf-8").read()
reparsed = json.loads(raw)
size = os.path.getsize(OUT)
total_senses = sum(len(r["senses"]) for r in reparsed)

# uncertain-source words
uncertain = [r["word"] for r in reparsed if "来源不确定" in r["root"]]

print("FILE:", OUT)
print("BYTES:", size)
print("WORDS:", len(reparsed), "->", [r["word"] for r in reparsed])
print("TOTAL_SENSES:", total_senses)
print("SENSES_PER_WORD:", [len(r["senses"]) for r in reparsed])
print("UNCERTAIN_SOURCE:", uncertain)
print("GLOBAL_UNIQUE_WORDS:", unique_all)
print("GLOBAL_DUPLICATES:", len(dups))
print("SKIPPED_UNREADABLE:", skipped_files)
print("WARNINGS:", len(warnings))
for x in warnings[:20]:
    print("  ~", x)
print("ALL CHECKS PASSED")
