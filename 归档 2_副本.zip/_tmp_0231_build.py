# 0231 批次组装与校验（临时文件，批次号唯一，不参与运行时）
import json
import re
import glob
import sys

sys.path.insert(0, ".")
from _tmp_0231_p1 import RECORDS as R1
from _tmp_0231_p2 import RECORDS as R2
from _tmp_0231_p3 import RECORDS as R3

TARGET = [
    "vary", "withstand", "aggravate", "alleviate", "circumvent",
    "deteriorate", "eradicate", "hinder", "intensify", "mitigate",
    "offset", "provoke", "reconcile", "surpass", "ecological balance",
]

KEYS = [
    "word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image",
    "scene", "sceneCN", "pos", "collocations", "forms", "derivatives", "senses",
    "etymology", "similar", "mnemonics", "examples", "dict_mnemonic", "root",
    "sensesIntro", "semanticMap", "affixes",
]

SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]

RECORDS = R1 + R2 + R3
PATH = "toefl-core-5000-0231.json"
problems = []


def bad(msg):
    problems.append(msg)


def build_forms(word):
    forms = {word, word + "s", word + "es", word + "ed", word + "ing", word + "d"}
    if word.endswith("e"):
        forms.add(word[:-1] + "ing")
    last = word[-1]
    forms.add(word + last + "ing")
    forms.add(word + last + "ed")
    return forms


IRREGULAR = {
    "withstand": ["withstood"],
    "offset": ["offsetting"],
}


def lexical_forms(word):
    forms = build_forms(word)
    if word.endswith("y"):
        forms.add(word[:-1] + "ies")
        forms.add(word[:-1] + "ied")
    for extra in IRREGULAR.get(word, []):
        forms.add(extra)
    return forms


def contains_word(sentence, word, forms=None):
    for form in (forms or lexical_forms(word)):
        if re.search(r"\b" + re.escape(form) + r"\b", sentence, re.I):
            return True
    return False


def blank_check(scene, word):
    sentence = re.sub(r"^[^A-Za-z]*", "", scene)
    forms = sorted(build_forms(word), key=len, reverse=True)
    hits = 0
    for form in forms:
        hits += len(re.findall(r"\b" + re.escape(form) + r"\b", sentence, re.I))
    return hits, sentence


zh_fields = []
en_fields = []

for i, rec in enumerate(RECORDS):
    word = rec.get("word")
    tag = "第%d条[%s]" % (i + 1, word)
    if list(rec.keys()) != KEYS:
        bad("%s 键序或键集合不符" % tag)
    if word != TARGET[i]:
        bad("%s 与目标顺序不符" % tag)

    # senses
    senses = rec["senses"]
    if not (8 <= len(senses) <= 10):
        bad("%s 义项数 %d 不在 8-10" % (tag, len(senses)))
    for j, s in enumerate(senses):
        if list(s.keys()) != SENSE_KEYS:
            bad("%s 义项%d 键不符" % (tag, j + 1))
        if s["no"] != "%02d" % (j + 1):
            bad("%s 义项编号错 %s" % (tag, s["no"]))
        if not contains_word(s["example"], word):
            bad("%s 义项%d 例句缺目标词" % (tag, j + 1))
        zh_fields.append((tag + " 义项%d titleCN" % (j + 1), s["titleCN"]))
        zh_fields.append((tag + " 义项%d definitionCN" % (j + 1), s["definitionCN"]))
        zh_fields.append((tag + " 义项%d exampleCN" % (j + 1), s["exampleCN"]))
        zh_fields.append((tag + " 义项%d whyCN" % (j + 1), s["whyCN"]))
        en_fields.append((tag + " 义项%d title" % (j + 1), s["title"]))
        en_fields.append((tag + " 义项%d definition" % (j + 1), s["definition"]))
        en_fields.append((tag + " 义项%d example" % (j + 1), s["example"]))
        en_fields.append((tag + " 义项%d why" % (j + 1), s["why"]))

    # etymology
    items = rec["etymology"]["items"]
    if not (5 <= len(items) <= 6):
        bad("%s 词源段数 %d" % (tag, len(items)))
    for it in items:
        if list(it.keys()) != ["era", "en", "cn"]:
            bad("%s 词源段键不符" % tag)
        if it["era"] != it["era"].upper():
            bad("%s 词源 era 未大写 %s" % (tag, it["era"]))
        en_fields.append((tag + " 词源 en", it["en"]))
        zh_fields.append((tag + " 词源 cn", it["cn"]))
    en_fields.append((tag + " 词源 intro", rec["etymology"]["intro"]["en"]))
    zh_fields.append((tag + " 词源 intro", rec["etymology"]["intro"]["cn"]))

    # semantic map
    sm = rec["semanticMap"]
    if len(sm["chain"]) != 6:
        bad("%s 语义链 %d 环" % (tag, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        bad("%s 分支数 %d" % (tag, len(sm["branches"])))
    valid = {s["no"] for s in senses}
    for b in sm["branches"]:
        if list(b.keys()) != ["senses", "en", "cn"]:
            bad("%s 分支键不符" % tag)
        nums = re.findall(r"\d{2}", b["senses"])
        if not nums:
            bad("%s 分支无编号" % tag)
        for n in nums:
            if n not in valid:
                bad("%s 分支回指悬空 %s" % (tag, n))

    # similar
    sim = rec["similar"]
    if [g["heading"] for g in sim["groups"]] != ["LOOK-ALIKE", "NEAR MEANING"]:
        bad("%s similar 分组名不符" % tag)
    if len(sim["groups"][0]["entries"]) < 3 or len(sim["groups"][1]["entries"]) < 3:
        bad("%s similar 条目过少" % tag)
    for g in sim["groups"]:
        for e in g["entries"]:
            if list(e.keys()) != ["word", "ipa", "tag", "definition", "definitionCN"]:
                bad("%s similar 条目键不符" % tag)
            zh_fields.append((tag + " similar 释义", e["definitionCN"]))

    # mnemonics
    mn = rec["mnemonics"]
    if len(mn["normal"]) != 5 or len(mn["abstract"]) != 3:
        bad("%s 联想条数不符" % tag)

    # examples
    if len(rec["examples"]) != 3:
        bad("%s 例句数 %d" % (tag, len(rec["examples"])))
    for e in rec["examples"]:
        if not contains_word(e["en"], word):
            bad("%s 例句缺目标词" % tag)

    # collocations / forms / derivatives
    if not (4 <= len(rec["collocations"]) <= 7):
        bad("%s 搭配数 %d" % (tag, len(rec["collocations"])))
    if len(rec["forms"]) < 4:
        bad("%s 变形过少" % tag)
    if len(rec["derivatives"]) < 1:
        bad("%s 无派生词" % tag)
    for c in rec["collocations"]:
        if list(c.keys()) != ["phrase", "zh"]:
            bad("%s 搭配键不符" % tag)
        zh_fields.append((tag + " 搭配", c["zh"]))
    for f in rec["forms"]:
        if list(f.keys()) != ["label", "form"]:
            bad("%s 变形键不符" % tag)
    for d in rec["derivatives"]:
        if list(d.keys()) != ["word", "pos", "zh"]:
            bad("%s 派生键不符" % tag)
        zh_fields.append((tag + " 派生释义", d["zh"]))
    for pp in rec["pos"]:
        if list(pp.keys()) != ["tag", "zh"]:
            bad("%s 词性键不符" % tag)
        zh_fields.append((tag + " 词性", pp["zh"]))

    # affixes
    af = rec["affixes"]
    if [k for k in af.keys()] != ["intro", "latinIntro", "items", "latinEntries", "derivatives"]:
        bad("%s affixes 键不符" % tag)
    if not (8 <= len(af["items"]) <= 12):
        bad("%s affixes items %d 条" % (tag, len(af["items"])))
    for a in af["items"]:
        if list(a.keys()) != ["word", "structure", "meaning", "meaningCN", "example", "exampleCN"]:
            bad("%s affix 条目键不符" % tag)
        zh_fields.append((tag + " affix 释义", a["meaningCN"]))
    for l in af["latinEntries"]:
        if list(l.keys()) != ["word", "structure", "meaning", "meaningCN"]:
            bad("%s latinEntries 键不符" % tag)
    if len(af["derivatives"]) < 1:
        bad("%s affixes derivatives 为空" % tag)
    en_fields.append((tag + " affix intro", af["intro"]["en"]))
    zh_fields.append((tag + " affix intro", af["intro"]["cn"]))
    en_fields.append((tag + " affix latinIntro", af["latinIntro"]["en"]))
    zh_fields.append((tag + " affix latinIntro", af["latinIntro"]["cn"]))

    # scene
    hits, sentence = blank_check(rec["scene"], word)
    if hits != 1:
        bad("%s 场景句目标词命中 %d 次" % (tag, hits))
    prefix = rec["scene"][: rec["scene"].find(sentence[0]) ] if sentence else ""
    if re.search(r"[A-Za-z0-9]", prefix):
        bad("%s 场景中文铺垫含拉丁字母或数字" % tag)
    if "第" not in rec["sceneCN"] or "个义项" not in rec["sceneCN"]:
        bad("%s sceneCN 缺义项引用" % tag)
    if re.search(r"[A-Za-z]", rec["sceneCN"]):
        bad("%s sceneCN 混入拉丁字母" % tag)

    zh_fields.append((tag + " definition_zh", rec["definition_zh"]))
    zh_fields.append((tag + " core_image", rec["core_image"]))
    zh_fields.append((tag + " root", rec["root"]))
    zh_fields.append((tag + " dict_text", rec["dict_mnemonic"]["text"]))
    zh_fields.append((tag + " sensesIntro", rec["sensesIntro"]["cn"]))
    zh_fields.append((tag + " map core", rec["semanticMap"]["core"]["cn"]))
    for b in sm["branches"]:
        zh_fields.append((tag + " map branch", b["cn"]))
    en_fields.append((tag + " definition_en", rec["definition_en"]))
    en_fields.append((tag + " dict word", rec["dict_mnemonic"]["word"]))
    en_fields.append((tag + " sensesIntro", rec["sensesIntro"]["en"]))
    en_fields.append((tag + " map core", rec["semanticMap"]["core"]["en"]))
    for m in mn["normal"] + mn["abstract"]:
        en_fields.append((tag + " 联想 en", m["en"]))
        zh_fields.append((tag + " 联想 cn", m["cn"]))
    for b in sm["branches"]:
        en_fields.append((tag + " map branch en", b["en"]))
    for g in sim["groups"]:
        for e in g["entries"]:
            en_fields.append((tag + " similar en", e["definition"]))
    for l in af["latinEntries"]:
        en_fields.append((tag + " latin en", l["meaning"]))
        zh_fields.append((tag + " latin cn", l["meaningCN"]))

# 中英混杂：普通叙述字段严禁拉丁字母；词源、形近释义、联想等引证型字段允许单词引文，但禁止成串英文
SOFT_LABELS = ("词源 cn", "词源 intro", "similar 释义", "affix intro", "affix latinIntro", "root", "联想 cn")

for name, text in zh_fields:
    if any(k in name for k in SOFT_LABELS):
        if re.search(r"[A-Za-z][A-Za-z'\-]*(\s+[A-Za-z][A-Za-z'\-]*){2,}", text):
            bad("%s 含成串英文：%s" % (name, text))
    else:
        if re.search(r"[A-Za-z]", text):
            bad("%s 混入拉丁字母：%s" % (name, text))
for name, text in en_fields:
    if re.search(r"[\u4e00-\u9fff]", text):
        bad("%s 混入中文：%s" % (name, text))

# 空值与占位
def walk(obj, path):
    if obj is None:
        bad("%s 为 null" % path)
    elif isinstance(obj, str):
        if not obj.strip():
            bad("%s 为空串" % path)
        if obj.strip().lower() in ("undefined", "null", "nan", "n/a", "tbd", "todo"):
            bad("%s 为占位串" % path)
        if re.search(r"[\u200b-\u200d\ufeff]", obj):
            bad("%s 含零宽字符" % path)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            walk(v, path + "." + k)
    elif isinstance(obj, list):
        for idx, v in enumerate(obj):
            walk(v, path + "[%d]" % idx)

for i, rec in enumerate(RECORDS):
    walk(rec, "第%d条" % (i + 1))

if len(RECORDS) != 15:
    bad("记录数 %d" % len(RECORDS))

if problems:
    print("校验失败 %d 项：" % len(problems))
    for p in problems:
        print(" -", p)
    sys.exit(1)

with open(PATH, "w", encoding="utf-8") as fh:
    json.dump(RECORDS, fh, ensure_ascii=False, indent=1)

# 落盘后二次解析
with open(PATH, encoding="utf-8") as fh:
    again = json.load(fh)
assert isinstance(again, list) and len(again) == 15
assert all(list(r.keys()) == KEYS for r in again)

print("OK 写入", PATH)
print("义项总数", sum(len(r["senses"]) for r in again))
print("来源不确定词", [r["word"] for r in again if "来源不确定" in json.dumps(
    {"e": r["etymology"], "root": r["root"]}, ensure_ascii=False)])

# 首见年代不确定（非来源存疑）
print("首见年代不确定词", [r["word"] for r in again if "首见年代" in r["root"]])

# 全库重名检查
seen = {}
dup = 0
files = sorted(glob.glob("toefl-core-5000-*.json"))
for fp in files:
    if fp.endswith("duplicate-positions.json"):
        continue
    try:
        data = json.load(open(fp, encoding="utf-8"))
    except Exception:
        continue
    if not isinstance(data, list):
        continue
    for rec in data:
        if isinstance(rec, dict) and rec.get("word"):
            w = rec["word"].strip().lower()
            seen.setdefault(w, []).append(fp)
dups = {w: fs for w, fs in seen.items() if len(fs) > 1}
print("全库唯一词数", len(seen))
print("重复词数", len(dups))
if dups:
    print("重复明细", json.dumps(dups, ensure_ascii=False))
