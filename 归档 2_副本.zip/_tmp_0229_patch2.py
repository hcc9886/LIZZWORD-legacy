import ast

FIX = {
    "Used by many": [
        '"Common use is reach translated into hands: the thing is not only present but picked up.",',
        '"常用是「覆盖」落到了手上：不只存在，而且被拿起来用。"),',
    ],
    "Damage across a wide area": [
        '"Damage takes the word when the area, not the depth, is what strikes observers.",',
        '"破坏用这个词，是因为触动观察者的是面积，而不是深度。"),',
    ],
    "Support from many quarters": [
        '"Support counts backers, so breadth becomes a political measure.",',
        '"支持数的是赞成者，广度于是成了政治上的尺度。"),',
    ],
    "A common practice": [
        '"A practice spreads by being copied, and reach again decides whether the word fits.",',
        '"做法靠被模仿而扩散，覆盖范围再次决定这个词是否合适。"),',
    ],
    "Shared worry": [
        '"A worry becomes widespread when strangers use the same sentence about it.",',
        '"当陌生人用同一句话谈论同一件忧心事，它就是普遍的。"),',
    ],
    "Demanding testing": [
        '"Tests are rigorous when the conditions are harder than ordinary use.",',
        '"当条件比日常使用更苛刻，测试就是严苛的。"),',
    ],
    "Hard training": [
        '"Training borrows the word because a strict method also trains the will.",',
        '"训练借用这个词，因为严格的方法也在训练意志。"),',
    ],
    "Standards without shortcuts": [
        '"A standard is rigorous when the exception costs more than the rule.",',
        '"当例外的代价高于规则，标准才是严格的。"),',
    ],
    "Analysis that checks its assumptions": [
        '"The analysis turns the strictness on itself, which is the highest form of the method.",',
        '"分析把严格对准自身，这是该方法最高的形态。"),',
    ],
    "Selection by hard tests": [
        '"Selection is rigorous when the gate, not the label, does the choosing.",',
        '"当做出选择的是门槛而不是标签，筛选才是严格的。"),',
    ],
    "Enforcement without leniency": [
        '"Enforcement completes the word: the rule now has hands as well as words.",',
        '"执行补全了这个词：规则如今不光有条文，还有手。"),',
    ],
    "A rule no longer in force": [
        '"Law keeps obsolete clauses on paper long after practice has left them.",',
        '"实践早已离开的条款，法律仍让它们留在纸上。"),',
    ],
    "A superseded machine": [
        '"A machine is obsolete when fixing it costs more than replacing it.",',
        '"当修理比替换更贵，机器就被淘汰了。"),',
    ],
    "An idea left behind": [
        '"Ideas age without breaking, which is why the word fits them so well.",',
        '"观念不会坏，只会老，所以这个词用在他们身上特别贴切。"),',
    ],
    "Old stock still on the shelf": [
        '"Stock becomes obsolete while it is still perfectly new in the box.",',
        '"存货在盒子里还崭新时，就已经成了淘汰货。"),',
    ],
    "A retired unit or currency": [
        '"Money and measures can be withdrawn by decree, and then the word is official.",',
        '"货币与单位可由法令停用，这时这个词是官方用语。"),',
    ],
    "A practice abandoned": [
        '"A habit disappears when the tool that carried it disappears first.",',
        '"当承载习惯的工具先消失，习惯也随之消失。"),',
    ],
    "A detailed pattern": [
        '"The pattern is intricate because the eye must travel along every line.",',
        '"图案错综，因为眼睛必须沿着每一条线走。"),',
    ],
    "Fine details": [
        '"Details are intricate when they cannot be understood one at a time.",',
        '"细节错综，是因为它们无法一件一件地单独理解。"),',
    ],
    "A tangled plot": [
        '"A plot is intricate when its threads return to the same scene from different sides.",',
        '"情节错综，是当它的线索从不同方向回到同一场景。"),',
    ],
    "Complex machinery": [
        '"Machinery earns the word when every part seems to be holding another.",',
        '"当每个部件似乎都在托住另一个，机器就用得上这个词。"),',
    ],
    "A complicated problem": [
        '"Problems are intricate when the causes cannot be pulled apart without breaking them.",',
        '"当原因一拆就断，问题就是盘根错节的。"),',
    ],
    "An involved relationship": [
        '"Relationships become intricate through obligations that overlap rather than multiply.",',
        '"关系因义务重叠、而不是数量增多，才变得错综。"),',
    ],
    "Fine workmanship": [
        '"Workmanship is intricate when smallness and care appear together.",',
        '"当细小与用心同时出现，工艺就是精细的。"),',
    ],
}

fname = "books/prepared/_tmp_0229_p4.py"
lines = open(fname, encoding="utf-8").read().split("\n")
tree = ast.parse("\n".join(lines))
targets = []
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "sense":
        title = node.args[1].value if len(node.args) > 1 and isinstance(node.args[1], ast.Constant) else None
        if title in FIX:
            targets.append((node.end_lineno - 1, len(node.args), title))
targets.sort(reverse=True)
for idx, n, title in targets:
    line = lines[idx]
    assert line.endswith("),"), (title, line)
    body = line[:-2]
    extra = FIX[title]
    assert len(extra) == 9 - n, (title, n, len(extra))
    lines[idx:idx + 1] = [body + ","] + ["              " + x for x in extra]
open(fname, "w", encoding="utf-8").write("\n".join(lines))
print("patched", len(targets))
