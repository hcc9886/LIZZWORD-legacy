# 0236 批次合并构建，临时文件，不参与运行时
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _tmp_0236_common import dump
from _tmp_0236_p1 import RECORDS as P1
from _tmp_0236_p2 import RECORDS as P2
from _tmp_0236_p3 import RECORDS as P3
from _tmp_0236_why import WHY

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "toefl-core-5000-0236.json")
ALL = P1 + P2 + P3
assert len(ALL) == 15, len(ALL)
missing = []
for r in ALL:
    for s in r["senses"]:
        if not s["why"] or not s["whyCN"]:
            sup = WHY.get((r["word"], s["no"]))
            if sup:
                s["why"], s["whyCN"] = sup
            else:
                missing.append((r["word"], s["no"]))
assert not missing, missing
dump(ALL, OUT)
print("WROTE", OUT, os.path.getsize(OUT))
