import ast

FIX = {
    "_tmp_0229_p1c.py": {
        "Spatial awareness": [
            '"Awareness adds the body to the map, so the sense moves from objects to one\'s own outline among them.",',
            '"「意识」把身体也放进地图，于是义项从物体移到自身在物体之间的轮廓。"),',
        ],
        "Worldly power": [
            '"The church set the authority of this world against the authority of the next, and the word carried the contrast.",',
            '"教会把此世的权力与彼世的权力对立起来，这个词就承载了这组对照。"),',
        ],
        "Temporal scale": [
            '"Scale is the length of the ruler, and on the time axis the ruler is a span of years.",',
            '"尺度就是尺子的长度；放在时间轴上，这把尺子就是一段年份。"),',
        ],
    },
    "_tmp_0229_p2.py": {
        "Results you can see": [
            '"Results become tangible when they can be pointed at in a report rather than promised in a speech.",',
            '"成果一旦能在报告里被指出、而不只是在演讲里被承诺，就变得「有形」。"),',
        ],
        "A cost that appears in the accounts": [
            '"Accounting names a cost tangible when it appears as a line rather than as a lost opportunity.",',
            '"会计把以一行数字出现、而非以错失机会出现的成本称为「有形成本」。"),',
        ],
        "An initial agreement": [
            '"An agreement is tentative while the signatures still wait for approval upstairs.",',
            '"协议在签名还等着上级批准时，就是初步的。"),',
        ],
        "A provisional conclusion": [
            '"A conclusion offered while data are still arriving is held provisionally by design.",',
            '"在数据仍陆续到来时给出的结论，按设计就是暂且持有的。"),',
        ],
        "A hesitant tone": [
            '"Caution moves from the plan to the voice, and the word now describes how someone speaks.",',
            '"谨慎从计划移到声音上，词于是描述一个人怎么说话。"),',
        ],
        "Exploratory in method": [
            '"A method is tentative when its first purpose is to find out whether it works at all.",',
            '"当一种方法的首要目的是弄清它究竟行不行，它就是试探性的。"),',
        ],
    },
    "_tmp_0229_p2b.py": {
        "A process anyone can follow": [
            '"A process is transparent when an outsider can follow every step without asking for files.",',
            '"当外部人不必索要文件就能跟上每一步，流程就是透明的。"),',
        ],
        "Government open to view": [
            '"The optical word became a demand that public business be visible to the public.",',
            '"这个光学词变成一项要求：公共事务必须对公众可见。"),',
        ],
        "Intentions easy to read": [
            '"Motives that can be read off behaviour are as visible as objects behind glass.",',
            '"从行为上就能读出的动机，和玻璃后面的物体一样可见。"),',
        ],
        "Accounts that can be checked": [
            '"Numbers presented so that any reader can redo the arithmetic are clear in the same way.",',
            '"呈现得让任何读者都能重算一遍的数字，以同样的方式「清楚」。"),',
        ],
        "Plainly true": [
            '"The last step of the metaphor: what needs no explanation is simply seen through.",',
            '"比喻的最后一步：无需解释的东西，就是被直接看穿的。"),',
        ],
        "An everyday trifle": [
            '"A matter is trivial when its size, not its difficulty, is the reason to ignore it.",',
            '"一件事被称为琐事，是因为它小，而不是因为它难。"),',
        ],
        "A cost too small to count": [
            '"Costs are trivial when the decision would be the same without them.",',
            '"成本在去掉它决策也不变时，就是微不足道的。"),',
        ],
        "An objection that misses the point": [
            '"An objection is trivial when it leaves the main claim standing.",',
            '"反对在主要主张仍然立得住时，就是无关紧要的。"),',
        ],
        "Small details used to avoid the issue": [
            '"Details become trivial when they are used to fill the space where the argument should be.",',
            '"当细节被用来填满本该放论证的位置，它们就成了细枝末节。"),',
        ],
        "Shallow talk": [
            '"Talk without substance earns the word because it leaves nothing behind.",',
            '"没有实质的谈话得到这个词，因为它什么也没留下。"),',
        ],
        "A minor fault": [
            '"Law calls a fault trivial when the penalty is lighter than the paperwork.",',
            '"当处罚比文书手续还轻时，法律就把该过失称为轻微的。"),',
        ],
        "Too simple to need comment": [
            '"The technical sense keeps the oldest idea: so common and easy that it needs no remark.",',
            '"技术义保留了最古老的意思：太寻常、太容易，因而不必再提。"),',
        ],
    },
    "_tmp_0229_p3.py": {
        "The basic structure": [
            '"A structure is underlying when removing it would collapse what stands on it.",',
            '"当抽掉它上面的东西就会塌，这个结构就是底层的。"),',
        ],
        "The asset behind a security": [
            '"金融借用了这个实物意象：纸张之下压着真东西。"),',
        ],
        "A condition already present": [
            '"Medicine says a condition is underlying when it was there before the illness being treated.",',
            '"医学把在正在治疗的疾病之前就已存在的状况称为基础疾病。"),',
        ],
        "A trend beneath short-term noise": [
            '"The trend is what remains after the monthly noise is averaged away.",',
            '"把月度噪声平均掉之后剩下的，就是潜在趋势。"),',
        ],
        "Deeper meaning": [
            '"Meaning can have layers too: the sentence on the surface, the request underneath.",',
            '"含义也能分层：表层是一句话，底下是一个请求。"),',
        ],
        "A risk not yet visible": [
            '"A risk is underlying while it exists in the system but has not yet produced an event.",',
            '"当风险存在于系统中却尚未酿成事件时，它就是潜在的。"),',
        ],
        "Rules with no exceptions": [
            '"A rule is uniform when the same words bind every case, including the ones the drafters dislike.",',
            '"当同样的条文约束每一情形、包括起草者不喜欢的情形，规则才是统一的。"),',
        ],
        "The same temperature throughout": [
            '"Heat spreads until every part reads the same number, which is sameness made measurable.",',
            '"热一直扩散到各处读数相同，这就是被量出来的「一致」。"),',
        ],
        "A field of equal value": [
            '"Physics states the sameness point by point: same strength, same direction, everywhere.",',
            '"物理把「相同」逐点写明：处处同强度、同方向。"),',
        ],
        "Found only in one place": [
            '"Location makes uniqueness easy to test: look elsewhere and find nothing.",',
            '"位置让「唯一」容易检验：到别处找，什么也找不到。"),',
        ],
        "An opportunity that will not return": [
            '"A chance is called unique when the calendar offers no second date for it.",',
            '"当日历上排不出第二个日期，这个机会就被称为难得。"),',
        ],
        "A style of one\'s own": [
            '"A manner repeated by nobody else is unique in the way a signature is.",',
            '"无人重复的做法是独特的，就像签名一样。"),',
        ],
        "A feature no rival has": [
            '"Markets name the feature no rival copies, and uniqueness becomes an argument for price.",',
            '"市场把对手无法复制的特点点出来，「唯一」于是成了定价的理由。"),',
        ],
        "A pattern that never repeats": [
            '"The pattern is unique because no second sample can reproduce it, not because it is beautiful.",',
            '"图案之所以独一无二，是因为没有第二个样本能复现，而不是因为它好看。"),',
        ],
    },
}

for fname, fixes in FIX.items():
    path = "books/prepared/" + fname
    lines = open(path, encoding="utf-8").read().split("\n")
    tree = ast.parse("\n".join(lines))
    targets = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "sense":
            title = node.args[1].value if len(node.args) > 1 and isinstance(node.args[1], ast.Constant) else None
            n = len(node.args)
            if title in fixes:
                targets.append((node.end_lineno - 1, n, title))
    targets.sort(reverse=True)
    for idx, n, title in targets:
        line = lines[idx].rstrip("\n")
        assert line.endswith("),"), (fname, title, line)
        body = line[:-2]
        extra = fixes[title]
        need = 9 - n
        assert len(extra) == need, (fname, title, n, len(extra))
        new = [body + ","]
        new.extend(["              " + x for x in extra])
        lines[idx : idx + 1] = new
    open(path, "w", encoding="utf-8").write("\n".join(lines))
    print("patched", fname, len(targets))
