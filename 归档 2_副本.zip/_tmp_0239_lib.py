# 0239 批次构建工具（临时文件，批次号唯一，不参与运行时）
import json


def s(no, title, titleCN, definition, definitionCN, example, exampleCN, why, whyCN):
    return {"no": "%02d" % no, "title": title, "titleCN": titleCN,
            "definition": definition, "definitionCN": definitionCN,
            "example": example, "exampleCN": exampleCN, "why": why, "whyCN": whyCN}


def p(tag, zh):
    return {"tag": tag, "zh": zh}


def c(phrase, zh):
    return {"phrase": phrase, "zh": zh}


def f(label, form):
    return {"label": label, "form": form}


def d(word, pos, zh):
    return {"word": word, "pos": pos, "zh": zh}


def se(word, ipa, tag, definition, definitionCN):
    return {"word": word, "ipa": ipa, "tag": tag, "definition": definition, "definitionCN": definitionCN}


def mn(en, cn):
    return {"en": en, "cn": cn}


def ex(en, cn):
    return {"en": en, "cn": cn}


def ety(era, en, cn):
    return {"era": era, "en": en, "cn": cn}


def aff(word, structure, meaning, meaningCN, example, exampleCN):
    return {"word": word, "structure": structure, "meaning": meaning, "meaningCN": meaningCN,
            "example": example, "exampleCN": exampleCN}


def lat(word, structure, meaning, meaningCN):
    return {"word": word, "structure": structure, "meaning": meaning, "meaningCN": meaningCN}


def rec(**k):
    return {
        "word": k["word"],
        "ipa_uk": k["ipa_uk"],
        "ipa_us": k["ipa_us"],
        "definition_zh": k["definition_zh"],
        "definition_en": k["definition_en"],
        "core_image": k["core_image"],
        "scene": k["scene"],
        "sceneCN": k["sceneCN"],
        "pos": k["pos"],
        "collocations": k["collocations"],
        "forms": k["forms"],
        "derivatives": k["derivatives"],
        "senses": k["senses"],
        "etymology": {"intro": {"en": k["ety_intro"][0], "cn": k["ety_intro"][1]}, "items": k["ety_items"]},
        "similar": {
            "note": {"en": k["sim_note"][0], "cn": k["sim_note"][1]},
            "groups": [
                {"heading": "LOOK-ALIKE", "entries": k["sim_look"]},
                {"heading": "NEAR MEANING", "entries": k["sim_near"]},
            ],
        },
        "mnemonics": {
            "normalIntro": {"en": k["mn_intro"][0], "cn": k["mn_intro"][1]},
            "normal": k["mn_normal"],
            "abstract": k["mn_abstract"],
        },
        "examples": k["examples"],
        "dict_mnemonic": {"note": "谐音记忆 · 非词源", "text": k["dict_text"], "word": k["word"]},
        "root": k["root"],
        "sensesIntro": {"en": k["senses_intro"][0], "cn": k["senses_intro"][1]},
        "semanticMap": {
            "core": {"en": k["map_core"][0], "cn": k["map_core"][1]},
            "chain": k["map_chain"],
            "branches": [{"senses": b[0], "en": b[1], "cn": b[2]} for b in k["map_branches"]],
        },
        "affixes": {
            "intro": {"en": k["affix_intro"][0], "cn": k["affix_intro"][1]},
            "latinIntro": {"en": k["affix_latin_intro"][0], "cn": k["affix_latin_intro"][1]},
            "items": k["affix_items"],
            "latinEntries": k["affix_latin"],
            "derivatives": k["affix_deriv"],
        },
    }


KEYS = [
    "word", "ipa_uk", "ipa_us", "definition_zh", "definition_en", "core_image",
    "scene", "sceneCN", "pos", "collocations", "forms", "derivatives", "senses",
    "etymology", "similar", "mnemonics", "examples", "dict_mnemonic", "root",
    "sensesIntro", "semanticMap", "affixes",
]

SENSE_KEYS = ["no", "title", "titleCN", "definition", "definitionCN", "example", "exampleCN", "why", "whyCN"]
