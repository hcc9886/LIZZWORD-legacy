# 0228 批次合并与全量校验（完成后删除）
import sys, os, json, re, glob, importlib

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

KEY_ORDER = ["word","ipa_uk","ipa_us","definition_zh","definition_en","core_image","scene","sceneCN","pos","collocations","forms","derivatives","senses","etymology","similar","mnemonics","examples","dict_mnemonic","root","sensesIntro","semanticMap","affixes"]
SENSE_KEYS = ["no","title","titleCN","definition","definitionCN","example","exampleCN","why","whyCN"]

EXPECTED = ["disparity","exploitation","inconsistency","inhibition","interference","obstacle","unprecedented",
            "ubiquitous","versatile","viable","volatile","vigorous","superficial","sophisticated","scarce"]

entries = []
for i in range(1, 16):
    m = importlib.import_module("_tmp_0228_w%02d" % i)
    entries.extend(m.DATA)

errors, warns = [], []
CJK = re.compile(r"[\u4e00-\u9fff]")
LATIN = re.compile(r"[A-Za-z]")

def walk_strings(obj, path=""):
    if isinstance(obj, str):
        yield path, obj
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk_strings(v, "%s[%d]" % (path, i))
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk_strings(v, "%s.%s" % (path, k))

def page_forms(word):
    forms = {word, word + "s", word + "es", word + "ed", word + "ing", word + "d"}
    if word.endswith("e"):
        forms.add(word[:-1] + "ing")
    last = word[-1]
    forms.add(word + last + "ing")
    forms.add(word + last + "ed")
    return forms

BANNED_FORMS = {"denied", "refuted", "implied", "arises"}

if len(entries) != 15:
    errors.append("条数不是15：%d" % len(entries))
if [e["word"] for e in entries] != EXPECTED:
    errors.append("词序不符：%s" % [e["word"] for e in entries])

seen_words = set()
for e in entries:
    w = e["word"]
    if w in seen_words:
        errors.append("批内重名：%s" % w)
    seen_words.add(w)
    if list(e.keys()) != KEY_ORDER:
        errors.append("%s: 顶层键序不符 %s" % (w, list(e.keys())))
    for pa, s in walk_strings(e, w):
        if s.strip() == "":
            errors.append("%s: 空串" % pa)
        if s.strip().lower() in {"undefined", "null", "none", "nan", "tbd", "todo"}:
            errors.append("%s: 占位串 %s" % (pa, s))
        if any(ch in s for ch in "\u200b\u200c\u200d\ufeff"):
            errors.append("%s: 零宽字符" % pa)
    senses = e["senses"]
    n = len(senses)
    if not (8 <= n <= 10):
        errors.append("%s: 义项数 %d" % (w, n))
    nos = [s["no"] for s in senses]
    if nos != ["%02d" % i for i in range(1, n + 1)]:
        errors.append("%s: 义项编号不连续 %s" % (w, nos))
    for s in senses:
        if list(s.keys()) != SENSE_KEYS:
            errors.append("%s/%s: 义项键序不符 %s" % (w, s.get("no"), list(s.keys())))
        if w.lower() not in s["example"].lower():
            errors.append("%s/%s: 例句缺目标词 -> %s" % (w, s["no"], s["example"]))
        for field in ("definitionCN", "whyCN", "titleCN", "exampleCN"):
            if LATIN.search(s[field]):
                warns.append("%s/%s: %s 含拉丁字母" % (w, s["no"], field))
    et = e["etymology"]
    if not (5 <= len(et["items"]) <= 6):
        errors.append("%s: 词源段数 %d" % (w, len(et["items"])))
    for it in et["items"]:
        if list(it.keys()) != ["era", "en", "cn"]:
            errors.append("%s: 词源段落键 %s" % (w, list(it.keys())))
        if not it["era"].strip() or it["era"] != it["era"].upper():
            errors.append("%s: era 未大写 %s" % (w, it["era"]))
    sm = e["semanticMap"]
    if len(sm["chain"]) != 6:
        errors.append("%s: chain 长度 %d" % (w, len(sm["chain"])))
    if len(sm["branches"]) != 5:
        errors.append("%s: 分支数 %d" % (w, len(sm["branches"])))
    covered = []
    for b in sm["branches"]:
        if list(b.keys()) != ["senses", "en", "cn"]:
            errors.append("%s: branch 键 %s" % (w, list(b.keys())))
        ids = [x.strip() for x in b["senses"].split("·")]
        for i in ids:
            if i not in nos:
                errors.append("%s: 分支回指无效 %s" % (w, i))
            covered.append(i)
    if sorted(set(covered)) != sorted(nos):
        warns.append("%s: 分支未覆盖全部义项 covered=%s senses=%s" % (w, sorted(set(covered)), nos))
    if len(covered) != len(set(covered)):
        warns.append("%s: 分支义项重复 %s" % (w, covered))
    if len(e["similar"]["groups"]) != 2:
        errors.append("%s: similar 组数" % w)
    for g in e["similar"]["groups"]:
        if "heading" not in g or "entries" not in g:
            errors.append("%s: similar 组结构" % w)
        for f in g["entries"]:
            if list(f.keys()) != ["word", "ipa", "tag", "definition", "definitionCN"]:
                errors.append("%s: similar 条目键 %s" % (w, list(f.keys())))
            if CJK.search(f["definition"]) or not CJK.search(f["definitionCN"]):
                errors.append("%s: similar 中英字段错位 %s" % (w, f["word"]))
    mn = e["mnemonics"]
    if len(mn["normal"]) != 5 or len(mn["abstract"]) != 3:
        errors.append("%s: mnemonics %d/%d" % (w, len(mn["normal"]), len(mn["abstract"])))
    if len(e["examples"]) != 3:
        errors.append("%s: examples 数 %d" % (w, len(e["examples"])))
    for exi in e["examples"]:
        if w.lower() not in exi["en"].lower():
            errors.append("%s: 例句缺目标词 -> %s" % (w, exi["en"]))
    if not (4 <= len(e["collocations"]) <= 7):
        errors.append("%s: collocations %d" % (w, len(e["collocations"])))
    if not e["forms"]:
        errors.append("%s: forms 空" % w)
    if not (4 <= len(e["derivatives"]) <= 8):
        warns.append("%s: derivatives %d" % (w, len(e["derivatives"])))
    af = e["affixes"]
    if not (8 <= len(af["items"]) <= 12):
        errors.append("%s: affixes items %d" % (w, len(af["items"])))
    if "latinEntries" not in af or "derivatives" not in af:
        errors.append("%s: affixes 缺 latinEntries/derivatives" % w)
    if len(af["latinEntries"]) < 3:
        warns.append("%s: latinEntries 偏少 %d" % (w, len(af["latinEntries"])))
    # scene
    scene = e["scene"]
    m = re.search(r"[A-Za-z]", scene)
    if not m:
        errors.append("%s: scene 无英文句" % w)
    else:
        pre, sent = scene[:m.start()], scene[m.start():].strip()
        if LATIN.search(pre) or re.search(r"[0-9]", pre):
            errors.append("%s: scene 中文铺垫含拉丁字母或数字 -> %s" % (w, pre))
        cnt = len(re.findall(r"(?i)\b" + re.escape(w) + r"\b", sent))
        if cnt != 1:
            errors.append("%s: scene 目标词出现 %d 次 -> %s" % (w, cnt, sent))
        if not re.search(r"[.!?]$", sent):
            errors.append("%s: scene 英文句未完整收尾" % w)
        # 挖空自测：模拟页面 buildSpeakBlank
        forms = page_forms(w)
        ordered = sorted(forms, key=len, reverse=True)
        blank = None
        hit_form = None
        for form in ordered:
            if form.lower() in BANNED_FORMS:
                continue
            if re.search(r"\b" + re.escape(form) + r"\b", sent, re.I):
                blank = re.sub(r"\b" + re.escape(form) + r"\b", "____", sent, count=1, flags=re.I)
                hit_form = form
                break
        if blank is None:
            errors.append("%s: scene 无法被页面生成词形挖空" % w)
        else:
            if w.lower() in blank.lower():
                errors.append("%s: 挖空后仍残留目标词（命中词形 %s）" % (w, hit_form))
            if "____" not in blank:
                errors.append("%s: 挖空无占位" % w)
    cn = e["sceneCN"]
    mnum = re.search(r"第\s*(\d+)\s*个义项", cn)
    if not mnum:
        errors.append("%s: sceneCN 缺「第 N 个义项」" % w)
    else:
        idx = "%02d" % int(mnum.group(1))
        if idx not in nos:
            errors.append("%s: sceneCN 义项号无效 %s" % (w, idx))
    if re.search(r"\b" + re.escape(w) + r"\b", cn, re.I):
        warns.append("%s: sceneCN 出现目标词英文" % w)

# 全库重名（排除元数据与非批次文件）
os.chdir(BASE)
SKIP_MARKS = ("diagnostic", "duplicate", "coverage", "meta", "_deprecated", "deprecated", "manifest", "index")
all_words = {}
files = []
for f in sorted(glob.glob("toefl-core-5000-*.json")):
    low = f.lower()
    if any(k in low for k in SKIP_MARKS):
        continue
    if "0228" in f:
        continue
    try:
        data = json.load(open(f, encoding="utf-8"))
    except Exception:
        continue
    if not isinstance(data, list):
        continue
    files.append(f)
    for x in data:
        if isinstance(x, dict) and isinstance(x.get("word"), str):
            all_words.setdefault(x["word"], []).append(f)
dups = {k: v for k, v in all_words.items() if len(v) > 1}
for w in seen_words:
    if w in all_words:
        warns.append("全库重名：%s 已存在于 %s" % (w, all_words[w]))

out = "toefl-core-5000-0228.json"
with open(out, "w", encoding="utf-8") as fh:
    json.dump(entries, fh, ensure_ascii=False, indent=1)
raw = open(out, encoding="utf-8").read()
if any(ch in raw for ch in "\u200b\u200c\u200d\ufeff"):
    errors.append("落盘文件含零宽字符")
data2 = json.load(open(out, encoding="utf-8"))
if len(data2) != 15:
    errors.append("落盘二次解析条数不符 %d" % len(data2))
if [x["word"] for x in data2] != EXPECTED:
    errors.append("落盘二次解析词序不符")
if list(data2[0].keys()) != KEY_ORDER:
    errors.append("落盘二次解析键序不符")

print("\n=== 输出 ===")
print("文件:", os.path.abspath(out))
print("字节:", os.path.getsize(out))
print("词数:", len(entries), "词序一致:", [e["word"] for e in entries] == EXPECTED)
print("义项总数:", sum(len(x["senses"]) for x in entries))
print("每词义项数:", [len(x["senses"]) for x in entries])
print("全库批次文件数:", len(files))
print("全库唯一词:", len(all_words), "全库重复词:", len(dups))
print("本批重复:", [w for w in seen_words if w in all_words])
uncertain = []
for x in entries:
    blob = json.dumps(x.get("etymology", {}), ensure_ascii=False) + x.get("root", "")
    if "来源不确定" in blob or "source uncertain" in blob:
        uncertain.append(x["word"])
print("来源不确定词:", uncertain)
print("\n=== ERRORS:", len(errors), "===")
for x in errors:
    print(" -", x)
print("\n=== WARNS:", len(warns), "===")
for x in warns:
    print(" ?", x)
sys.exit(0 if not errors else 1)
